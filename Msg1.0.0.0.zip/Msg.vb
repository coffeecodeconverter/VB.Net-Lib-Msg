﻿
'AUTHOR: CoffeeCodeConverter
'GITHUB: https://github.com/coffeecodeconverter
'CREATION Date:   08/07/2025

' ------------------------------
'REQUIREMENTS:
' ------------------------------
'.NET Framework 4.5.1 Or higher


' ------------------------------
' DESCRIPTION:
' ------------------------------
' A FULLY Customizable Dialog Box!
' Intended to become "Messagebox 2.0"! Handling all of the limitations, plus many quality of life features! 
' The System messagebox cant do much, and you often find yourself having to create custom dialogs to handle essentially ANY case more complicated than a simple string. 
' This "Msg" class replaces the purpose of "Messagebox.Show()" with "Msg.Box()" [a callback / homeage to the old VB days]
' Msg.Box() mimics messgebox.show() as closely as possible in terms of argument list, plus extra features. (see below) 
' quick list of features:
'   headings as well as titles - in richtext format
'   messages in richtext format
'   additional footer - also in richtext format
'   customize the icon using any image 
'   include a picture with the dialog 
'   customise the buttons 
'   Auto sizes the form based on content 
'   Auto scrolls content that exceeeds form size
'   customise the theme, style, layout, size, and position of the dialog. 
'   timed messages (down to milliseconds,) - with visible ETA/Countdown
'   optional help button, with custom function assignment 
'   (basically, EVERYTHING the original MessageBox.Show() LACKED!!!) 


' ------------------------------
' KEY FEATURES IN MORE DETAIL:  
' ------------------------------
' Has its own classes and enums so it integrates with intelliSense for easier coding (for icons and button options, exactly how messagebox.Show() works)
' Has its own button Options that are more customizable compared to the built-in messageBoxButtons, and they can be expanded upon 
' Has a class for themes and layouts, to change colours and button styles by passing a single object argument. 
' Automatically adapts its layout based on arguments passed - such as icon, heading, message, picture, and footer. 
' Ability to show message for specified duration then auto close - Overrides the help button (help functions might breaks flow of events, which could interfere with a timed message)
' Optional "Help" button that automatically appears if you pass a custom 'helpFunction' which is then assigned to the button. NOTE: passing a duration for a timed message overrides and HIDES the help button!
' Auto-sizes the form's width based on longest line in message and/or heading length - whichevers longest, and the form's height based on message line count. 
' Has a max size for the form as a whole, and if content exceeds, scrollbars automatically appear (unlike Messagebox.show() which truncated the content)
' Note: Size and Position can also be overidden if desired. 
' Higher resolution Icons for the built-in system MessageboxIcons, plus, additonal 'Confimation' icon in green, Plus, extra customizable icons for a modern look. 
' Ability to include a picture / screenshot in the dialog - layout automatically adjust if picture is passed as an argument. 
' The heading, message, and footer are all richtextboxes - meaning they support full richtext formatting, not just plain text! Get Creative!
' Most arguments are optional, so it still accepts a simple function call like this: 'Msg.Box("hello world")' 
' Uses a workaround to prevent Heading being Selected, without affecting its colourization. 
' Ability to set a default button, fallsback to the furthest right button being highlighted. 

' -----------------------
' PRIMARY FUNCTION:
' -----------------------
' Box(message,
'     title,
'     Heading,
'     footer,
'     buttonOption,
'     icon,
'     picture,
'     defaultButton,
'     theme,
'     helpFunction,
'     duration,
'     X,
'     Y,
'     Width,
'     Height,
'     layout) As DialogResultCustom


' ------------------
' BASIC USAGE:
' ------------------
' dim newDialog as new Msg 
' newDialog.box("Hello World")


' ----------------------------------------------
' Similar Usage compare to Messagebox.Show():
' ----------------------------------------------
' dim newDialog as new Msg 
' newDialog.box("Hello World", "Title", "Example Heading", "this is a footer message", MsgButtons.OK, MsgIcons.Information, picture.image, defaultButton.OK, )


' ------------------
' ADVANCED USAGE:
' ------------------
' dim newDialog as new Msg 

'customTheme = New Msg.MessageBoxTheme With {
'        .BackColor = color.White,
'        .FontColor = color.Black,
'        .FooterColor = color.Gray,
'        .ButtonColor = color.LightGray,
'        .ButtonFontColor = color.Black,
'        .ButtonStyle = FlatStyle.Standard
'    }

' newDialog.box("Hello World",
'               "Title",
'               "Example Heading",
'               "this is a footer message",
'               MsgButtons.OK,
'               MsgIcons.Information,
'               picture.image,
'               defaultButton.OK,
'               customTheme)









Imports System.Reflection
Imports System.Text.RegularExpressions

Public Class Msg

    Public Shared defaultThemeMsg_BackColour As Color = Color.White
    Public Shared defaultThemeMsg_FontColour As Color = Color.Black
    Public Shared defaultThemeMsg_FooterColour As Color = SystemColors.ButtonFace
    Public Shared defaultThemeMsg_ButtonColour As Color = SystemColors.ControlLightLight
    Public Shared defaultThemeMsg_ButtonFontColour As Color = Color.Black
    Public Shared defaultThemeMsg_ButtonStyle As FlatStyle = FlatStyle.Standard

    ' OPTIONAL - This is so any custom function can be assigned to a Help Button - CHANGE THE RETURN VALUE IF YOU WANT THIS IS JUST TO DEMONSTRATE
    Private helpFunctionStored As Func(Of String) = Nothing

    ' For Timed Dialogs and a visible countdown 
    Private durationTimer As Timer
    Private remainingTime As TimeSpan

    Public Enum MsgButtons
        OK
        Cancel
        Yes
        No
        ContinueOn
    End Enum


    Public Enum ButtonOptions
        OK
        OKCancel
        OKNo
        OKNoCancel
        YesNo
        YesNoCancel
        CancelContinue
        NoContinue
    End Enum

    Public Enum DefaultButton
        OK
        Cancel
        Yes
        No
        ContinueOn
    End Enum


    Private Function GetButtonsFromOption(passedOption As ButtonOptions) As MsgButtons()
        Select Case passedOption
            Case ButtonOptions.OK
                Return {MsgButtons.OK}
            Case ButtonOptions.OKCancel
                Return {MsgButtons.OK, MsgButtons.Cancel}
            Case ButtonOptions.OKNo
                Return {MsgButtons.OK, MsgButtons.No}
            Case ButtonOptions.OKNoCancel
                Return {MsgButtons.OK, MsgButtons.No, MsgButtons.Cancel}
            Case ButtonOptions.YesNo
                Return {MsgButtons.Yes, MsgButtons.No}
            Case ButtonOptions.YesNoCancel
                Return {MsgButtons.Yes, MsgButtons.No, MsgButtons.Cancel}
            Case ButtonOptions.CancelContinue
                Return {MsgButtons.ContinueOn, MsgButtons.Cancel}
            Case ButtonOptions.NoContinue
                Return {MsgButtons.ContinueOn, MsgButtons.No}
            Case Else
                Return {MsgButtons.OK}
        End Select
    End Function


    Public Function FormatButtonOption(optionName As String) As String
        Return optionName.Replace("OKCancel", "OK, Cancel").
                      Replace("OKNoCancel", "OK, No, Cancel").
                      Replace("OKNo", "OK, No").
                      Replace("YesNoCancel", "Yes, No, Cancel").
                      Replace("YesNo", "Yes, No").
                      Replace("CancelContinue", "Cancel, Continue").
                      Replace("NoContinue", "No, Continue").
                      Replace("OK", "OK") ' Keep single OK clean
    End Function


    Private clickedResult As DialogResultCustom = DialogResultCustom.None

    Public Enum DialogResultCustom
        None
        OK
        Cancel
        Yes
        No
        ContinueOn
    End Enum


    Public Function GetButtonOptionFromText(selectedText As String) As ButtonOptions
        Dim normalizedText As String = selectedText.Trim().ToLower()
        Select Case normalizedText
            Case "ok"
                Return ButtonOptions.OK
            Case "ok, cancel"
                Return ButtonOptions.OKCancel
            Case "ok, no"
                Return ButtonOptions.OKNo
            Case "ok, no, cancel"
                Return ButtonOptions.OKNoCancel
            Case "yes, no"
                Return ButtonOptions.YesNo
            Case "yes, no, cancel"
                Return ButtonOptions.YesNoCancel
            Case "cancel, continue"
                Return ButtonOptions.CancelContinue
            Case "no, continue"
                Return ButtonOptions.NoContinue
            Case Else
                Throw New ArgumentException("Invalid button option selected: " & selectedText)
        End Select
    End Function


    Public Structure LayoutConfig
        Public description As String
        Public ColumnWidth As Integer
        Public RowStyles As Single()
        Public MinimumSize As Size
        Public ShowPicture As Boolean
    End Structure


    Public Enum MsgLayout
        Message
        Message_Picture
        Message_Footer
        Message_Picture_Footer
        Heading_Message
        Heading_Message_Picture
        Heading_Message_Footer
        Heading_Message_Picture_Footer
        Picture
        Picture_Footer
        Heading_Picture
        Heading_Picture_Footer
        Icon_Message
        Icon_Message_Picture
        Icon_Message_Footer
        Icon_Message_Picture_Footer
        Icon_Heading_Message
        Icon_Heading_Message_Picture
        Icon_Heading_Message_Footer
        Icon_Heading_Message_Picture_Footer
        Icon_Picture
        Icon_Picture_Footer
        Icon_Heading_Picture
        Icon_Heading_Picture_Footer
    End Enum


    ' Helper Function Maps Enum to Description
    Private Function LayoutEnumToDescription(layout As MsgLayout) As String
        Return layout.ToString().Replace("_", ", ")
    End Function


    Public Layouts As LayoutConfig() = {
    New LayoutConfig With {.description = "Message", .ColumnWidth = 0, .RowStyles = {25, -100, 0, 0}, .MinimumSize = New Size(310, 125), .ShowPicture = True},
    New LayoutConfig With {.description = "Message, Picture", .ColumnWidth = 0, .RowStyles = {25, 80, -100, 15}, .MinimumSize = New Size(320, 350), .ShowPicture = True},
    New LayoutConfig With {.description = "Message, Footer", .ColumnWidth = 0, .RowStyles = {25, -100, 10, 80}, .MinimumSize = New Size(310, 255), .ShowPicture = False},
    New LayoutConfig With {.description = "Message, Picture, Footer", .ColumnWidth = 0, .RowStyles = {25, 80, -100, 80}, .MinimumSize = New Size(320, 420), .ShowPicture = True},
    New LayoutConfig With {.description = "Heading, Message", .ColumnWidth = 0, .RowStyles = {25, -100, 0, 0}, .MinimumSize = New Size(310, 190), .ShowPicture = True},
    New LayoutConfig With {.description = "Heading, Message, Picture", .ColumnWidth = 0, .RowStyles = {25, 80, -100, 15}, .MinimumSize = New Size(320, 375), .ShowPicture = True},
    New LayoutConfig With {.description = "Heading, Message, Footer", .ColumnWidth = 0, .RowStyles = {25, -100, 10, 80}, .MinimumSize = New Size(310, 280), .ShowPicture = False},
    New LayoutConfig With {.description = "Heading, Message, Picture, Footer", .ColumnWidth = 0, .RowStyles = {25, 80, -100, 80}, .MinimumSize = New Size(320, 445), .ShowPicture = True},
    New LayoutConfig With {.description = "Picture", .ColumnWidth = 0, .RowStyles = {0, 0, -100, 0}, .MinimumSize = New Size(320, 280), .ShowPicture = True},
    New LayoutConfig With {.description = "Picture, Footer", .ColumnWidth = 0, .RowStyles = {0, 0, -100, 80}, .MinimumSize = New Size(320, 360), .ShowPicture = True},
    New LayoutConfig With {.description = "Heading, Picture", .ColumnWidth = 0, .RowStyles = {25, 0, -100, 15}, .MinimumSize = New Size(320, 305), .ShowPicture = True},
    New LayoutConfig With {.description = "Heading, Picture, Footer", .ColumnWidth = 0, .RowStyles = {25, 0, -100, 80}, .MinimumSize = New Size(320, 385), .ShowPicture = True},
    New LayoutConfig With {.description = "Icon, Message", .ColumnWidth = 66, .RowStyles = {25, -100, 10, 0}, .MinimumSize = New Size(310, 125), .ShowPicture = False},
    New LayoutConfig With {.description = "Icon, Message, Picture", .ColumnWidth = 66, .RowStyles = {25, 80, -100, 15}, .MinimumSize = New Size(380, 350), .ShowPicture = True},
    New LayoutConfig With {.description = "Icon, Message, Footer", .ColumnWidth = 66, .RowStyles = {25, -100, 10, 80}, .MinimumSize = New Size(310, 255), .ShowPicture = False},
    New LayoutConfig With {.description = "Icon, Message, Picture, Footer", .ColumnWidth = 66, .RowStyles = {25, 80, -100, 80}, .MinimumSize = New Size(310, 420), .ShowPicture = True},
    New LayoutConfig With {.description = "Icon, Heading, Message", .ColumnWidth = 66, .RowStyles = {25, -100, 0, 0}, .MinimumSize = New Size(310, 190), .ShowPicture = True},
    New LayoutConfig With {.description = "Icon, Heading, Message, Picture", .ColumnWidth = 66, .RowStyles = {25, 80, -100, 15}, .MinimumSize = New Size(380, 375), .ShowPicture = True},
    New LayoutConfig With {.description = "Icon, Heading, Message, Footer", .ColumnWidth = 66, .RowStyles = {25, -100, 10, 80}, .MinimumSize = New Size(310, 280), .ShowPicture = False},
    New LayoutConfig With {.description = "Icon, Heading, Message, Picture, Footer", .ColumnWidth = 66, .RowStyles = {25, 80, -100, 80}, .MinimumSize = New Size(380, 445), .ShowPicture = True},
    New LayoutConfig With {.description = "Icon, Picture", .ColumnWidth = 66, .RowStyles = {0, 0, -100, 0}, .MinimumSize = New Size(380, 280), .ShowPicture = True},
    New LayoutConfig With {.description = "Icon, Picture, Footer", .ColumnWidth = 66, .RowStyles = {0, 0, -100, 80}, .MinimumSize = New Size(380, 360), .ShowPicture = True},
    New LayoutConfig With {.description = "Icon, Heading, Picture", .ColumnWidth = 66, .RowStyles = {25, 0, -100, 0}, .MinimumSize = New Size(380, 305), .ShowPicture = True},
    New LayoutConfig With {.description = "Icon, Heading, Picture, Footer", .ColumnWidth = 66, .RowStyles = {25, 0, -100, 80}, .MinimumSize = New Size(380, 385), .ShowPicture = True}
    }



    Public Shared MsgIconImages As New Dictionary(Of MsgIcon, Image)

    Public Shared Sub LoadMsgIconImages()
        Dim assembly As Assembly = Assembly.GetExecutingAssembly()
        Dim baseNamespace As String = "Msg."

        Dim iconResourcePaths As New Dictionary(Of MsgIcon, String) From {
            {MsgIcon.WindowsWarning, baseNamespace & "icon_WindowsWarning.png"},
            {MsgIcon.WindowsError, baseNamespace & "icon_WindowsError.png"},
            {MsgIcon.WindowsInformation, baseNamespace & "icon_WindowsInformation.png"},
            {MsgIcon.WindowsQuestion, baseNamespace & "icon_WindowsQuestion.png"},
            {MsgIcon.WindowsConfirmation, baseNamespace & "icon_WindowsConfirmation.png"},
            {MsgIcon.WindowsWarningMargin, baseNamespace & "icon_WindowsWarningMargin.png"},
            {MsgIcon.WindowsErrorMargin, baseNamespace & "icon_WindowsErrorMargin.png"},
            {MsgIcon.WindowsInformationMargin, baseNamespace & "icon_WindowsInformationMargin.png"},
            {MsgIcon.WindowsQuestionMargin, baseNamespace & "icon_WindowsQuestionMargin.png"},
            {MsgIcon.WindowsConfirmationMargin, baseNamespace & "icon_WindowsConfirmationMargin.png"},
            {MsgIcon.Warning, baseNamespace & "icon_Warning.png"},
            {MsgIcon.ErrorRed, baseNamespace & "icon_Error.png"},
            {MsgIcon.Information, baseNamespace & "icon_Information.png"},
            {MsgIcon.Question, baseNamespace & "icon_Question.png"},
            {MsgIcon.Confirmation, baseNamespace & "icon_Confirmation.png"},
            {MsgIcon.WarningMargin, baseNamespace & "icon_WarningMargin.png"},
            {MsgIcon.ErrorRedMargin, baseNamespace & "icon_ErrorMargin.png"},
            {MsgIcon.InformationMargin, baseNamespace & "icon_InformationMargin.png"},
            {MsgIcon.QuestionMargin, baseNamespace & "icon_QuestionMargin.png"},
            {MsgIcon.ConfirmationMargin, baseNamespace & "icon_ConfirmationMargin.png"}
        }

        For Each kvp In iconResourcePaths
            Try
                Using stream = assembly.GetManifestResourceStream(kvp.Value)
                    If stream IsNot Nothing Then
                        MsgIconImages(kvp.Key) = Image.FromStream(stream)
                    Else
                        Debug.WriteLine($"[Warning] Resource not found: {kvp.Value}")
                    End If
                End Using
            Catch ex As Exception
                Debug.WriteLine($"[Error] Failed to load embedded icon {kvp.Value}: {ex.Message}")
            End Try
        Next
    End Sub





    Public Enum MsgIcon
        WindowsWarning
        WindowsError
        WindowsInformation
        WindowsQuestion
        WindowsConfirmation
        WindowsWarningMargin
        WindowsErrorMargin
        WindowsInformationMargin
        WindowsQuestionMargin
        WindowsConfirmationMargin
        Warning
        ErrorRed
        Information
        Question
        Confirmation
        WarningMargin
        ErrorRedMargin
        InformationMargin
        QuestionMargin
        ConfirmationMargin
    End Enum


    Public Function GetMsgIcon(iconType As MsgIcon) As Image
        Try
            If MsgIconImages.ContainsKey(iconType) Then
                Return MsgIconImages(iconType)
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MessageBox.Show("Error getting Icon from 'MsgIconImages' Dictionary: " & ex.Message & vbCrLf & vbCrLf & ex.StackTrace)
            Return Nothing
        End Try
    End Function


    Public Class MessageBoxTheme
        Public Property BackColor As Color = SystemColors.Control
        Public Property FooterColor As Color = SystemColors.Control
        Public Property FontColor As Color = SystemColors.ControlText
        Public Property ButtonColor As Color = SystemColors.Control
        Public Property ButtonFontColor As Color = SystemColors.ControlText
        Public Property ButtonStyle As FlatStyle = FlatStyle.Standard
    End Class





    Public Sub New()
        InitializeComponent()
        Me.StartPosition = FormStartPosition.CenterScreen
        LoadMsgIconImages()
    End Sub


    Private Sub Msg_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub


    Private Sub Msg_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        Me.TopMost = True
        Me.TopMost = False
        FlowLayoutPanel_ResponseButtons.Focus()
    End Sub




    Private Sub Button_OK_Click(sender As Object, e As EventArgs) Handles Button_OK.Click
        clickedResult = DialogResultCustom.OK
        Me.Close()
    End Sub


    Private Sub Button_Cancel_Click(sender As Object, e As EventArgs) Handles Button_Cancel.Click
        clickedResult = DialogResultCustom.Cancel
        Me.Close()
    End Sub


    Private Sub Button_Yes_Click(sender As Object, e As EventArgs) Handles Button_Yes.Click
        clickedResult = DialogResultCustom.Yes
        Me.Close()
    End Sub


    Private Sub Button_No_Click(sender As Object, e As EventArgs) Handles Button_No.Click
        clickedResult = DialogResultCustom.No
        Me.Close()
    End Sub


    Private Sub Button_Continue_Click(sender As Object, e As EventArgs) Handles Button_Continue.Click
        clickedResult = DialogResultCustom.ContinueOn
        Me.Close()
    End Sub


    Private Sub Button_Help_Click(sender As Object, e As EventArgs) Handles Button_Help.Click
        If helpFunctionStored IsNot Nothing Then
            ' THIS CAN BE EDITED / CUSTOMIZED TO DO ANYTHING ELSE YOU WANT THE HELP BUTTONS TO DO - THIS IS JUST A DEMO 
            Dim helpText As String = helpFunctionStored.Invoke()
            MessageBox.Show(helpText, "Help", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub


    Private Sub RichTextBox_Heading_TextChanged(sender As Object, e As EventArgs) Handles RichTextBox_Heading.TextChanged

    End Sub


    Private Sub RichTextBox_Heading_MouseClick(sender As Object, e As MouseEventArgs) Handles RichTextBox_Heading.MouseClick
        DeSelectTitle()
    End Sub


    Private Sub RichTextBox_Heading_MouseDown(sender As Object, e As MouseEventArgs) Handles RichTextBox_Heading.MouseDown
        DeSelectTitle()
    End Sub


    Private Sub RichTextBox_Heading_MouseEnter(sender As Object, e As EventArgs) Handles RichTextBox_Heading.MouseEnter
        DeSelectTitle()
    End Sub


    Private Sub RichTextBox_Heading_MouseHover(sender As Object, e As EventArgs) Handles RichTextBox_Heading.MouseHover
        DeSelectTitle()
    End Sub


    Private Sub RichTextBox_Heading_MouseLeave(sender As Object, e As EventArgs) Handles RichTextBox_Heading.MouseLeave
        DeSelectTitle()
    End Sub


    Private Sub RichTextBox_Heading_MouseMove(sender As Object, e As MouseEventArgs) Handles RichTextBox_Heading.MouseMove
        DeSelectTitle()
    End Sub


    Private Sub RichTextBox_Heading_MouseUp(sender As Object, e As MouseEventArgs) Handles RichTextBox_Heading.MouseUp
        DeSelectTitle()
    End Sub







    Public Sub IncludeButtons(ParamArray buttonOptions() As MsgButtons)
        Button_OK.Visible = False
        Button_Cancel.Visible = False
        Button_Yes.Visible = False
        Button_No.Visible = False
        Button_Continue.Visible = False

        FlowLayoutPanel_ResponseButtons.Controls.Clear()

        For Each btn As MsgButtons In buttonOptions
            Select Case btn
                Case MsgButtons.OK
                    Button_OK.Visible = True
                    FlowLayoutPanel_ResponseButtons.Controls.Add(Button_OK)
                Case MsgButtons.Cancel
                    Button_Cancel.Visible = True
                    FlowLayoutPanel_ResponseButtons.Controls.Add(Button_Cancel)
                Case MsgButtons.Yes
                    Button_Yes.Visible = True
                    FlowLayoutPanel_ResponseButtons.Controls.Add(Button_Yes)
                Case MsgButtons.No
                    Button_No.Visible = True
                    FlowLayoutPanel_ResponseButtons.Controls.Add(Button_No)
                Case MsgButtons.ContinueOn
                    Button_Continue.Visible = True
                    FlowLayoutPanel_ResponseButtons.Controls.Add(Button_Continue)
            End Select
        Next
    End Sub





    Private Function DetermineLayout(message As String,
                                 heading As String,
                                 footer As String,
                                 icon As Image,
                                 picture As Image) As String

        Dim layoutParts As New List(Of String)

        If icon IsNot Nothing Then layoutParts.Add("Icon")
        If Not String.IsNullOrWhiteSpace(heading) Then layoutParts.Add("Heading")
        If Not String.IsNullOrWhiteSpace(message) Then layoutParts.Add("Message")
        If picture IsNot Nothing Then layoutParts.Add("Picture")
        If Not String.IsNullOrWhiteSpace(footer) Then layoutParts.Add("Footer")

        Return String.Join(", ", layoutParts)
    End Function





    Public Sub ApplyLayout(layoutIndex As Integer)
        If layoutIndex < 0 OrElse layoutIndex >= Layouts.Length Then Exit Sub

        Dim config As LayoutConfig = Layouts(layoutIndex)

        ' Setup TableLayout
        TableLayoutPanel_MsgBox.ColumnCount = 2
        TableLayoutPanel_MsgBox.RowCount = 4

        TableLayoutPanel_MsgBox.ColumnStyles.Clear()
        TableLayoutPanel_MsgBox.ColumnStyles.Add(New ColumnStyle(SizeType.Absolute, config.ColumnWidth))
        TableLayoutPanel_MsgBox.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 100))

        TableLayoutPanel_MsgBox.RowStyles.Clear()

        'Debug.WriteLine($"   ------------------------------------------------------")
        'Debug.WriteLine($"   Layout:           {config.description}")
        'Debug.WriteLine($"   ShowPicture:      {config.ShowPicture}")
        'Debug.WriteLine($"   Column 1 Width:   {config.ColumnWidth}")

        For i As Integer = 0 To config.RowStyles.Length - 1
            Dim style = config.RowStyles(i)

            If style = -1 Then
                TableLayoutPanel_MsgBox.RowStyles.Add(New RowStyle(SizeType.Percent, 100))
                'Debug.WriteLine($"   Row {i}:            Percent 100% (from -1 special case)")
            ElseIf style < 0 Then
                TableLayoutPanel_MsgBox.RowStyles.Add(New RowStyle(SizeType.Percent, Math.Abs(style)))
                'Debug.WriteLine($"   Row {i}:            Percent {Math.Abs(style)}% (from negative value)")
            ElseIf style = 100 Then
                TableLayoutPanel_MsgBox.RowStyles.Add(New RowStyle(SizeType.Percent, 100))
                'Debug.WriteLine($"   Row {i}:            Percent 100% (from 100 literal)")
            Else
                TableLayoutPanel_MsgBox.RowStyles.Add(New RowStyle(SizeType.Absolute, style))
                'Debug.WriteLine($"   Row {i}:            Absolute {style}px")
            End If
        Next
        'Debug.WriteLine($"   ------------------------------------------------------")

        ' Other settings
        PictureBox_Picture.Visible = config.ShowPicture
        Me.MinimumSize = config.MinimumSize
    End Sub



    Private Sub ApplyTheme(Optional theme As MessageBoxTheme = Nothing)
        ' Fallback to defaults if no theme provided
        Dim backColour As Color = If(theme?.BackColor, defaultThemeMsg_BackColour)
        Dim footerColour As Color = If(theme?.FooterColor, defaultThemeMsg_FooterColour)
        Dim fontColour As Color = If(theme?.FontColor, defaultThemeMsg_FontColour)
        Dim buttonColour As Color = If(theme?.ButtonColor, defaultThemeMsg_ButtonColour)
        Dim buttonFontColour As Color = If(theme?.ButtonFontColor, defaultThemeMsg_ButtonFontColour)
        Dim buttonStyle As FlatStyle = If(theme?.ButtonStyle, defaultThemeMsg_ButtonStyle)

        Me.BackColor = backColour
        Panel_FormFooter.BackColor = footerColour

        RichTextBox_Heading.BackColor = backColour
        RichTextBox_Heading.ForeColor = fontColour

        RichTextBox_Message.BackColor = backColour
        RichTextBox_Message.ForeColor = fontColour

        RichTextBox_Footer.BackColor = backColour
        RichTextBox_Footer.ForeColor = fontColour

        For Each ctrl As Control In FlowLayoutPanel_ResponseButtons.Controls
            If TypeOf ctrl Is Button Then
                Dim btn As Button = CType(ctrl, Button)
                btn.BackColor = buttonColour
                btn.ForeColor = buttonFontColour
                btn.FlatStyle = buttonStyle
            End If
        Next

        Button_Help.BackColor = buttonColour
        Button_Help.ForeColor = buttonFontColour
        Button_Help.FlatStyle = buttonStyle

        Label_TimerCountdown.ForeColor = fontColour
    End Sub





    ' OVERLOADING the SetMSG_Layout() function to Accept an Enum, Description, or Index

    '1
    Public Sub SetMSG_Layout(layout As MsgLayout, ParamArray buttonOptions() As MsgButtons)
        Dim description As String = LayoutEnumToDescription(layout)
        SetMSG_Layout(description, buttonOptions)
    End Sub

    '2
    Public Sub SetMSG_Layout(layoutDescription As String, ParamArray buttonOptions() As MsgButtons)
        Try
            Dim layoutIndex As Integer = Array.FindIndex(Layouts, Function(l) String.Equals(l.description, layoutDescription, StringComparison.OrdinalIgnoreCase))

            If layoutIndex = -1 Then
                Throw New ArgumentException($"Layout '{layoutDescription}' not found.")
            End If

            ApplyLayout(layoutIndex)
            IncludeButtons(buttonOptions)
        Catch ex As Exception
            Debug.WriteLine("Error Showing message: " & ex.Message & " --- TRACE: " & ex.StackTrace)
            MessageBox.Show("Error Showing message: " & ex.Message & " --- TRACE: " & ex.StackTrace)
        End Try
    End Sub

    '3
    Public Sub SetMSG_Layout(layoutIndex As Integer, ParamArray buttonOptions() As MsgButtons)
        If layoutIndex < 0 OrElse layoutIndex >= Layouts.Length Then
            Throw New ArgumentOutOfRangeException(NameOf(layoutIndex), "Invalid layout index.")
        End If

        ApplyLayout(layoutIndex)
        IncludeButtons(buttonOptions)
    End Sub



    ' Other SetMSG Functions:
    Private Sub SetMSG_Title(passedMessage As String)
        Me.Text = passedMessage
    End Sub

    Private Sub SetMSG_Heading(passedMessage As String)
        If IsRtf(passedMessage) Then
            RichTextBox_Heading.Rtf = passedMessage
        Else
            RichTextBox_Heading.Text = passedMessage
        End If
    End Sub

    Private Sub SetMSG_Message(passedMessage As String)
        If IsRtf(passedMessage) Then
            RichTextBox_Message.Rtf = passedMessage
        Else
            RichTextBox_Message.Text = passedMessage
        End If
    End Sub

    Private Sub SetMSG_Footer(passedMessage As String)
        If IsRtf(passedMessage) Then
            RichTextBox_Footer.Rtf = passedMessage
        Else
            RichTextBox_Footer.Text = passedMessage
        End If
    End Sub

    Private Sub SetMSG_Position(newX As Integer, newY As Integer)
        Me.Location = New Point(newX, newY)
    End Sub


    Private Sub SetMSG_Size(newWidth As Integer, newHeight As Integer)
        Me.Size = New Size(newWidth, newHeight)
    End Sub



    Private Sub SetMSG_AutoSize()
        Try
            ' Use raw input (RTF or plain text) and normalize it
            Dim rawMessageText As String = ConvertRtfToPlainText(RichTextBox_Message.Rtf)
            Dim messageLines As String() = rawMessageText.Split({vbCrLf, vbLf}, StringSplitOptions.None)

            Dim totalLines As Integer = messageLines.Length
            Dim lineHeight As Integer = TextRenderer.MeasureText("A", RichTextBox_Message.Font).Height
            Dim desiredHeight As Integer = (totalLines * lineHeight) + 20 ' Padding

            ' Longest line for width
            Dim longestLine As String = messageLines.OrderByDescending(Function(l) l.Length).FirstOrDefault()
            If longestLine Is Nothing Then longestLine = ""

            Dim messageTextSize As Size = TextRenderer.MeasureText(longestLine & "WW", RichTextBox_Message.Font)
            Dim desiredWidth As Integer = messageTextSize.Width + 40 ' Padding

            ' Do same for heading
            Dim rawHeadingText As String = ConvertRtfToPlainText(RichTextBox_Heading.Rtf)
            Dim headingLine As String = rawHeadingText.Split({vbCrLf, vbLf}, StringSplitOptions.None).
                                OrderByDescending(Function(l) l.Length).FirstOrDefault()
            If headingLine Is Nothing Then headingLine = ""

            Dim headingTextSize As Size = TextRenderer.MeasureText(headingLine & "WW", RichTextBox_Heading.Font)
            Dim headingWidth As Integer = headingTextSize.Width + 40

            desiredWidth = Math.Max(desiredWidth, headingWidth)

            ' Offset by borders/buttons
            Dim nonTextHeight As Integer = Me.Height - RichTextBox_Message.Height
            Dim nonTextWidth As Integer = Me.Width - RichTextBox_Message.Width

            Dim totalFormHeight As Integer = desiredHeight + nonTextHeight
            Dim totalFormWidth As Integer = desiredWidth + nonTextWidth

            ' Apply limits
            If totalFormHeight > Me.MaximumSize.Height Then totalFormHeight = Me.MaximumSize.Height
            If totalFormWidth > Me.MaximumSize.Width Then totalFormWidth = Me.MaximumSize.Width

            Me.Height = totalFormHeight
            Me.Width = totalFormWidth
        Catch ex As Exception
            MessageBox.Show("Error in SetMSG_AutoSize: " & ex.Message & " --- TRACE: " & ex.StackTrace)
        End Try
    End Sub



    ' Workaround - Stops Title Being Selected without affecting colour (i.e. unlike enabled=false would)
    Private Sub DeSelectTitle()
        RichTextBox_Heading.DeselectAll()
        RichTextBox_Heading.SelectionStart = 0
        RichTextBox_Heading.ScrollToCaret()
        FlowLayoutPanel_ResponseButtons.Focus()
    End Sub




    ' PRIMARY FUNCTION
    Public Function Box(message As String,
                                      Optional title As String = "",
                                      Optional Heading As String = Nothing,
                                      Optional footer As String = Nothing,
                                      Optional buttonOption As ButtonOptions = ButtonOptions.OK,
                                      Optional icon As Image = Nothing,
                                      Optional picture As Image = Nothing,
                                      Optional defaultButton As DefaultButton? = Nothing,
                                      Optional theme As MessageBoxTheme = Nothing,
                                      Optional helpFunction As Func(Of String) = Nothing,
                                      Optional duration As Integer? = Nothing,
                                      Optional X As Integer? = Nothing,
                                      Optional Y As Integer? = Nothing,
                                      Optional Width As Integer? = Nothing,
                                      Optional Height As Integer? = Nothing,
                                      Optional layoutDescription As String = "") As DialogResultCustom

        Try
            ' Determine layout if not specified
            If String.IsNullOrWhiteSpace(layoutDescription) Then
                layoutDescription = DetermineLayout(message, Heading, footer, icon, picture)
            End If

            Dim validLayout = Layouts.Any(Function(l) l.description = layoutDescription)
            If Not validLayout Then
                layoutDescription = "Icon, Message" ' fallback
            End If

            ' Apply layout
            SetMSG_Layout(layoutDescription, GetButtonsFromOption(buttonOption))
            SetMSG_Title(title)
            ApplyTheme(theme)

            SetMSG_Message(message)
            SetMSG_Heading(Heading)
            SetMSG_Footer(footer)


            Dim defaultBtn As Button = Nothing

            ' Try to find the matching default button by text if provided
            If defaultButton.HasValue Then
                For Each ctrl As Control In FlowLayoutPanel_ResponseButtons.Controls
                    If TypeOf ctrl Is Button Then
                        Dim btn As Button = DirectCast(ctrl, Button)

                        If String.Equals(btn.Text, defaultButton.Value.ToString(), StringComparison.OrdinalIgnoreCase) Then
                            defaultBtn = btn
                            Exit For
                        End If
                    End If
                Next
            End If

            ' Fallback to first button if no match found
            If defaultBtn Is Nothing Then
                For Each ctrl As Control In FlowLayoutPanel_ResponseButtons.Controls
                    If TypeOf ctrl Is Button Then
                        defaultBtn = DirectCast(ctrl, Button)
                        Exit For
                    End If
                Next
            End If

            ' Apply default if one was found
            If defaultBtn IsNot Nothing Then
                Me.AcceptButton = defaultBtn
            End If

            If X.HasValue AndAlso Y.HasValue Then
                Me.StartPosition = FormStartPosition.Manual
                SetMSG_Position(X.Value, Y.Value)
            Else
                Me.StartPosition = FormStartPosition.CenterScreen
                Me.CenterToScreen()
            End If


            If Width.HasValue AndAlso Height.HasValue Then
                SetMSG_Size(Width, Height)
            Else
                SetMSG_AutoSize()
            End If


            If picture IsNot Nothing Then PictureBox_Picture.Image = picture
            If icon IsNot Nothing Then PictureBox_Icon.Image = icon



            ' Reset result
            clickedResult = DialogResultCustom.None

            If duration Is Nothing OrElse duration = 0 Then
                Label_TimerCountdown.Visible = False

                If helpFunction Is Nothing Then
                    Button_Help.Visible = False
                    Button_Help.Enabled = False
                    helpFunctionStored = Nothing
                Else
                    Button_Help.Visible = True
                    Button_Help.Enabled = True
                    helpFunctionStored = helpFunction
                End If
            Else
                ' Show countdown label
                Label_TimerCountdown.Visible = True

                ' Hide help button
                Button_Help.Visible = False
                Button_Help.Enabled = False
                helpFunctionStored = Nothing

                ' Set up timer and time span
                remainingTime = TimeSpan.FromMilliseconds(duration.Value)

                Label_TimerCountdown.Text = remainingTime.ToString("mm\:ss\.fff")

                durationTimer = New Timer()
                durationTimer.Interval = 20
                AddHandler durationTimer.Tick, AddressOf DurationTimer_Tick
                durationTimer.Start()
            End If

            Me.ShowDialog()

            ' Return result after form closes
            Return clickedResult

        Catch ex As Exception
            MessageBox.Show("Error in Primary 'Box' Function: " & ex.Message & " --- TRACE: " & ex.StackTrace)
            Return DialogResultCustom.None
        End Try

    End Function



    ' For Timed Messages
    Private Sub DurationTimer_Tick(sender As Object, e As EventArgs)
        remainingTime = remainingTime - TimeSpan.FromMilliseconds(durationTimer.Interval)

        If remainingTime.TotalMilliseconds <= 0 Then
            durationTimer.Stop()
            Label_TimerCountdown.Text = "00:00.000"
            clickedResult = DialogResultCustom.None
            Me.Close()
        Else
            Label_TimerCountdown.Text = remainingTime.ToString("mm\:ss\.fff")
        End If
    End Sub



    ' For Richtext Formatting

    Public Shared Function IsRichText(rtb As RichTextBox) As Boolean
        Dim rtf As String = rtb.Rtf

        ' Quick short-circuit: plain text RTFs are short and simple
        If rtf.Contains("\colortbl") OrElse
       rtf.Contains("\highlight") OrElse
       rtf.Contains("\cf") OrElse
       rtf.Contains("\b") OrElse
       rtf.Contains("\i") OrElse
       rtf.Contains("\ul") OrElse
       rtf.Contains("\strike") OrElse
       rtf.Contains("\fs") AndAlso rtf.IndexOf("\fs") <> rtf.LastIndexOf("\fs") OrElse ' Multiple font sizes
       rtf.Contains("\sa") OrElse rtf.Contains("\sl") OrElse
       rtf.Contains("\fbidis") OrElse rtf.Contains("\ltrpar") Then

            Return True ' Actual formatting exists
        End If

        ' If all we see is a very basic header, it's likely plain text
        Return False
    End Function


    Private Function IsRtf(input As String) As Boolean
        If String.IsNullOrWhiteSpace(input) OrElse Not input.TrimStart().StartsWith("{\rtf", StringComparison.OrdinalIgnoreCase) Then
            Return False
        End If

        ' Look for common formatting tags that suggest it's not just plain text
        Dim formattingPattern As String = "(\\colortbl|\\highlight|\\cf\d+|\\b|\\i|\\ul|\\strike|\\sa\d+|\\sl\d+|\\fbidis|\\ltrpar)"
        Return Regex.IsMatch(input, formattingPattern, RegexOptions.IgnoreCase)
    End Function


    Private Function RichTextBox_PlainTextFromRtf(rtf As String) As String
        Using tempRtb As New RichTextBox()
            Try
                tempRtb.Rtf = rtf
                Return tempRtb.Text
            Catch
                Return rtf ' fallback in case of malformed input
            End Try
        End Using
    End Function


    Private Function ConvertRtfToPlainText(rtf As String) As String
        Using rtb As New RichTextBox()
            Try
                rtb.Rtf = rtf
                Return rtb.Text
            Catch
                Return rtf ' If not valid RTF, just return as-is
            End Try
        End Using
    End Function




    Public Shared Sub ResetRichTextBox(ByRef rtb As RichTextBox)
        Dim parent = rtb.Parent
        Dim location = rtb.Location
        Dim size = rtb.Size
        Dim name = rtb.Name
        Dim tabIndex = rtb.TabIndex
        Dim anchor = rtb.Anchor
        Dim dock = rtb.Dock

        Dim originialText As String = rtb.Text

        ' Remove old control
        parent.Controls.Remove(rtb)
        rtb.Dispose()

        ' Create new one
        Dim newRtb As New RichTextBox()
        newRtb.Location = location
        newRtb.Size = size
        newRtb.Name = name
        newRtb.TabIndex = tabIndex
        newRtb.Anchor = anchor
        newRtb.Dock = dock

        ' (Optional) Apply default font/style if needed
        newRtb.Font = New Font("Microsoft Sans Serif", 8.25)

        ' Add to parent
        parent.Controls.Add(newRtb)

        ' Update your reference
        rtb = newRtb
        rtb.Text = originialText
    End Sub






    Private Sub Msg_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        If durationTimer IsNot Nothing Then
            durationTimer.Stop()
            durationTimer.Dispose()
            durationTimer = Nothing
        End If
    End Sub



End Class