﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Button_Quit = New System.Windows.Forms.Button()
        Me.ComboBox_ButtonOptions = New System.Windows.Forms.ComboBox()
        Me.ComboBox_LayoutOptions = New System.Windows.Forms.ComboBox()
        Me.RichTextBox_Form1_Heading = New System.Windows.Forms.RichTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.RichTextBox_Form1_Message = New System.Windows.Forms.RichTextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.RichTextBox_Form1_Footer = New System.Windows.Forms.RichTextBox()
        Me.TextBox_Form1_Title = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.PictureBox_PreviewPicture = New System.Windows.Forms.PictureBox()
        Me.CheckBox_ShowIcon = New System.Windows.Forms.CheckBox()
        Me.PictureBox_PreviewIcon = New System.Windows.Forms.PictureBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBox_X = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TextBox_Y = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TextBox_Height = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TextBox_Width = New System.Windows.Forms.TextBox()
        Me.Button_ShowMsg = New System.Windows.Forms.Button()
        Me.CheckBox_ShowHelpButton = New System.Windows.Forms.CheckBox()
        Me.ComboBox_HelpFunction = New System.Windows.Forms.ComboBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Panel_HelpFunction = New System.Windows.Forms.Panel()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.CheckBox_OverrideLayout = New System.Windows.Forms.CheckBox()
        Me.Panel_OverrideLayout = New System.Windows.Forms.Panel()
        Me.Button_OverrideLayoutReset = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Button_CompareToMessageBox = New System.Windows.Forms.Button()
        Me.CheckBox_ShowPicture = New System.Windows.Forms.CheckBox()
        Me.Button_BrowseForPicture = New System.Windows.Forms.Button()
        Me.Button_ResetPicture = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ComboBox_IconOptions = New System.Windows.Forms.ComboBox()
        Me.Button_Icon_Reset = New System.Windows.Forms.Button()
        Me.Button_Icon_Browse = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button_SimpleMsgNew = New System.Windows.Forms.Button()
        Me.Button_SimpleMsg = New System.Windows.Forms.Button()
        Me.Button_ShowMsgNew = New System.Windows.Forms.Button()
        Me.CheckBox_CustomTheme = New System.Windows.Forms.CheckBox()
        Me.Panel_Theme = New System.Windows.Forms.Panel()
        Me.ComboBox_Theme_Presets = New System.Windows.Forms.ComboBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Button_Theme_Reset = New System.Windows.Forms.Button()
        Me.ComboBox_Theme_ButtonStyles = New System.Windows.Forms.ComboBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.PictureBox_Theme_ButtonFontColour = New System.Windows.Forms.PictureBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.PictureBox_Theme_ButtonColour = New System.Windows.Forms.PictureBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.PictureBox_Theme_FooterColour = New System.Windows.Forms.PictureBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.PictureBox_Theme_FontColour = New System.Windows.Forms.PictureBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.PictureBox_Theme_BackColour = New System.Windows.Forms.PictureBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.CheckBox_OverrideSizePosition = New System.Windows.Forms.CheckBox()
        Me.Panel_OverrideSizePosition = New System.Windows.Forms.Panel()
        Me.CheckBox_TimedMessage = New System.Windows.Forms.CheckBox()
        Me.Panel_TimedDuration = New System.Windows.Forms.Panel()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.TextBox_Duration = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button_Code_Copy = New System.Windows.Forms.Button()
        Me.Button_Code_Clear = New System.Windows.Forms.Button()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.TextBox_ActualCode = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.ComboBox_DefaultButton = New System.Windows.Forms.ComboBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.TextBox_RTF_Message = New System.Windows.Forms.TextBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.TextBox_RTF_Heading = New System.Windows.Forms.TextBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.TextBox_RTF_Footer = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Button_RTF_RefreshMessage = New System.Windows.Forms.Button()
        Me.Button_RTF_RefreshHeading = New System.Windows.Forms.Button()
        Me.Button_RTF_RefreshFooter = New System.Windows.Forms.Button()
        Me.Button_RTF_ClearMessage = New System.Windows.Forms.Button()
        Me.Button_RTF_ClearHeading = New System.Windows.Forms.Button()
        Me.Button_RTF_ClearFooter = New System.Windows.Forms.Button()
        Me.Button_Form1_MessageClear = New System.Windows.Forms.Button()
        Me.Button_Form1_HeadingClear = New System.Windows.Forms.Button()
        Me.Button_Form1_FooterClear = New System.Windows.Forms.Button()
        Me.Button_Form1_HeadingAsPlain = New System.Windows.Forms.Button()
        Me.Button_Form1_MessageAsPlain = New System.Windows.Forms.Button()
        Me.Button_Form1_FooterAsPlain = New System.Windows.Forms.Button()
        CType(Me.PictureBox_PreviewPicture, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox_PreviewIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel_HelpFunction.SuspendLayout()
        Me.Panel_OverrideLayout.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.Panel_Theme.SuspendLayout()
        CType(Me.PictureBox_Theme_ButtonFontColour, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox_Theme_ButtonColour, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox_Theme_FooterColour, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox_Theme_FontColour, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox_Theme_BackColour, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel_OverrideSizePosition.SuspendLayout()
        Me.Panel_TimedDuration.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button_Quit
        '
        Me.Button_Quit.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Quit.BackColor = System.Drawing.Color.IndianRed
        Me.Button_Quit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Quit.ForeColor = System.Drawing.Color.White
        Me.Button_Quit.Location = New System.Drawing.Point(294, 181)
        Me.Button_Quit.Name = "Button_Quit"
        Me.Button_Quit.Size = New System.Drawing.Size(66, 31)
        Me.Button_Quit.TabIndex = 2
        Me.Button_Quit.Text = "Quit"
        Me.Button_Quit.UseVisualStyleBackColor = False
        '
        'ComboBox_ButtonOptions
        '
        Me.ComboBox_ButtonOptions.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_ButtonOptions.FormattingEnabled = True
        Me.ComboBox_ButtonOptions.Items.AddRange(New Object() {"OK", "OK, Cancel ", "OK, No", "OK, No, Cancel", "Yes, No", "Yes, No, Cancel", "Cancel, Continue", "No, Continue"})
        Me.ComboBox_ButtonOptions.Location = New System.Drawing.Point(55, 315)
        Me.ComboBox_ButtonOptions.Name = "ComboBox_ButtonOptions"
        Me.ComboBox_ButtonOptions.Size = New System.Drawing.Size(111, 21)
        Me.ComboBox_ButtonOptions.TabIndex = 17
        '
        'ComboBox_LayoutOptions
        '
        Me.ComboBox_LayoutOptions.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_LayoutOptions.FormattingEnabled = True
        Me.ComboBox_LayoutOptions.Items.AddRange(New Object() {"Message", "Message, Picture", "Message, Footer ", "Message, Picture, Footer ", "Heading, Message", "Heading, Message, Picture", "Heading, Message, Footer", "Heading, Message, Picture, Footer ", "Picture", "Picture, Footer ", "Heading, Picture", "Heading, Picture, Footer", "Icon, Message", "Icon, Message, Picture", "Icon, Message, Footer ", "Icon, Message, Picture, Footer ", "Icon, heading, Message", "Icon, heading, Message, Picture", "Icon, heading, Message, Footer", "Icon, heading, Message, Picture, Footer ", "Icon, Picture", "Icon, Picture, Footer ", "Icon, heading, Picture", "Icon, heading, Picture, Footer"})
        Me.ComboBox_LayoutOptions.Location = New System.Drawing.Point(3, 27)
        Me.ComboBox_LayoutOptions.Name = "ComboBox_LayoutOptions"
        Me.ComboBox_LayoutOptions.Size = New System.Drawing.Size(165, 21)
        Me.ComboBox_LayoutOptions.TabIndex = 16
        '
        'RichTextBox_Form1_Heading
        '
        Me.RichTextBox_Form1_Heading.Location = New System.Drawing.Point(7, 189)
        Me.RichTextBox_Form1_Heading.Name = "RichTextBox_Form1_Heading"
        Me.RichTextBox_Form1_Heading.Size = New System.Drawing.Size(340, 49)
        Me.RichTextBox_Form1_Heading.TabIndex = 18
        Me.RichTextBox_Form1_Heading.Text = ""
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 173)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(47, 13)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "Heading"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 62)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(50, 13)
        Me.Label2.TabIndex = 21
        Me.Label2.Text = "Message"
        '
        'RichTextBox_Form1_Message
        '
        Me.RichTextBox_Form1_Message.Location = New System.Drawing.Point(8, 79)
        Me.RichTextBox_Form1_Message.Name = "RichTextBox_Form1_Message"
        Me.RichTextBox_Form1_Message.Size = New System.Drawing.Size(338, 84)
        Me.RichTextBox_Form1_Message.TabIndex = 20
        Me.RichTextBox_Form1_Message.Text = "Test Message"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(4, 246)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(37, 13)
        Me.Label3.TabIndex = 23
        Me.Label3.Text = "Footer"
        '
        'RichTextBox_Form1_Footer
        '
        Me.RichTextBox_Form1_Footer.Location = New System.Drawing.Point(7, 262)
        Me.RichTextBox_Form1_Footer.Name = "RichTextBox_Form1_Footer"
        Me.RichTextBox_Form1_Footer.Size = New System.Drawing.Size(340, 51)
        Me.RichTextBox_Form1_Footer.TabIndex = 22
        Me.RichTextBox_Form1_Footer.Text = ""
        '
        'TextBox_Form1_Title
        '
        Me.TextBox_Form1_Title.Location = New System.Drawing.Point(7, 33)
        Me.TextBox_Form1_Title.Name = "TextBox_Form1_Title"
        Me.TextBox_Form1_Title.Size = New System.Drawing.Size(339, 20)
        Me.TextBox_Form1_Title.TabIndex = 25
        Me.TextBox_Form1_Title.Text = "testTitle"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(7, 17)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(27, 13)
        Me.Label4.TabIndex = 26
        Me.Label4.Text = "Title"
        '
        'PictureBox_PreviewPicture
        '
        Me.PictureBox_PreviewPicture.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox_PreviewPicture.BackColor = System.Drawing.Color.Black
        Me.PictureBox_PreviewPicture.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox_PreviewPicture.Enabled = False
        Me.PictureBox_PreviewPicture.Location = New System.Drawing.Point(659, 151)
        Me.PictureBox_PreviewPicture.Name = "PictureBox_PreviewPicture"
        Me.PictureBox_PreviewPicture.Size = New System.Drawing.Size(373, 231)
        Me.PictureBox_PreviewPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox_PreviewPicture.TabIndex = 27
        Me.PictureBox_PreviewPicture.TabStop = False
        '
        'CheckBox_ShowIcon
        '
        Me.CheckBox_ShowIcon.AutoSize = True
        Me.CheckBox_ShowIcon.Checked = True
        Me.CheckBox_ShowIcon.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox_ShowIcon.Location = New System.Drawing.Point(674, 13)
        Me.CheckBox_ShowIcon.Name = "CheckBox_ShowIcon"
        Me.CheckBox_ShowIcon.Size = New System.Drawing.Size(77, 17)
        Me.CheckBox_ShowIcon.TabIndex = 29
        Me.CheckBox_ShowIcon.Text = "Show Icon"
        Me.CheckBox_ShowIcon.UseVisualStyleBackColor = True
        '
        'PictureBox_PreviewIcon
        '
        Me.PictureBox_PreviewIcon.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox_PreviewIcon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox_PreviewIcon.Location = New System.Drawing.Point(674, 32)
        Me.PictureBox_PreviewIcon.Name = "PictureBox_PreviewIcon"
        Me.PictureBox_PreviewIcon.Size = New System.Drawing.Size(80, 80)
        Me.PictureBox_PreviewIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox_PreviewIcon.TabIndex = 30
        Me.PictureBox_PreviewIcon.TabStop = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(1, 8)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(14, 13)
        Me.Label7.TabIndex = 33
        Me.Label7.Text = "X"
        '
        'TextBox_X
        '
        Me.TextBox_X.Location = New System.Drawing.Point(17, 5)
        Me.TextBox_X.Name = "TextBox_X"
        Me.TextBox_X.Size = New System.Drawing.Size(50, 20)
        Me.TextBox_X.TabIndex = 32
        Me.TextBox_X.Text = "300"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(1, 31)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(14, 13)
        Me.Label8.TabIndex = 35
        Me.Label8.Text = "Y"
        '
        'TextBox_Y
        '
        Me.TextBox_Y.Location = New System.Drawing.Point(17, 28)
        Me.TextBox_Y.Name = "TextBox_Y"
        Me.TextBox_Y.Size = New System.Drawing.Size(50, 20)
        Me.TextBox_Y.TabIndex = 34
        Me.TextBox_Y.Text = "300"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(73, 31)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(38, 13)
        Me.Label9.TabIndex = 39
        Me.Label9.Text = "Height"
        '
        'TextBox_Height
        '
        Me.TextBox_Height.Location = New System.Drawing.Point(109, 28)
        Me.TextBox_Height.Name = "TextBox_Height"
        Me.TextBox_Height.Size = New System.Drawing.Size(50, 20)
        Me.TextBox_Height.TabIndex = 38
        Me.TextBox_Height.Text = "165"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(75, 8)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(35, 13)
        Me.Label10.TabIndex = 37
        Me.Label10.Text = "Width"
        '
        'TextBox_Width
        '
        Me.TextBox_Width.Location = New System.Drawing.Point(109, 5)
        Me.TextBox_Width.Name = "TextBox_Width"
        Me.TextBox_Width.Size = New System.Drawing.Size(50, 20)
        Me.TextBox_Width.TabIndex = 36
        Me.TextBox_Width.Text = "320"
        '
        'Button_ShowMsg
        '
        Me.Button_ShowMsg.Location = New System.Drawing.Point(16, 32)
        Me.Button_ShowMsg.Name = "Button_ShowMsg"
        Me.Button_ShowMsg.Size = New System.Drawing.Size(157, 23)
        Me.Button_ShowMsg.TabIndex = 41
        Me.Button_ShowMsg.Text = "Show Msg SAME Instance"
        Me.Button_ShowMsg.UseVisualStyleBackColor = True
        '
        'CheckBox_ShowHelpButton
        '
        Me.CheckBox_ShowHelpButton.AutoSize = True
        Me.CheckBox_ShowHelpButton.Location = New System.Drawing.Point(10, 423)
        Me.CheckBox_ShowHelpButton.Name = "CheckBox_ShowHelpButton"
        Me.CheckBox_ShowHelpButton.Size = New System.Drawing.Size(112, 17)
        Me.CheckBox_ShowHelpButton.TabIndex = 24
        Me.CheckBox_ShowHelpButton.Text = "Show Help Button"
        Me.CheckBox_ShowHelpButton.UseVisualStyleBackColor = True
        '
        'ComboBox_HelpFunction
        '
        Me.ComboBox_HelpFunction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_HelpFunction.FormattingEnabled = True
        Me.ComboBox_HelpFunction.Location = New System.Drawing.Point(3, 20)
        Me.ComboBox_HelpFunction.Name = "ComboBox_HelpFunction"
        Me.ComboBox_HelpFunction.Size = New System.Drawing.Size(288, 21)
        Me.ComboBox_HelpFunction.TabIndex = 42
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(3, 1)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(288, 13)
        Me.Label11.TabIndex = 43
        Me.Label11.Text = "Function to Assign to Help Button (you have to make these)"
        '
        'Panel_HelpFunction
        '
        Me.Panel_HelpFunction.Controls.Add(Me.Label11)
        Me.Panel_HelpFunction.Controls.Add(Me.ComboBox_HelpFunction)
        Me.Panel_HelpFunction.Enabled = False
        Me.Panel_HelpFunction.Location = New System.Drawing.Point(6, 443)
        Me.Panel_HelpFunction.Name = "Panel_HelpFunction"
        Me.Panel_HelpFunction.Size = New System.Drawing.Size(295, 42)
        Me.Panel_HelpFunction.TabIndex = 44
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(7, 319)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(46, 13)
        Me.Label12.TabIndex = 45
        Me.Label12.Text = "Buttons:"
        '
        'CheckBox_OverrideLayout
        '
        Me.CheckBox_OverrideLayout.AutoSize = True
        Me.CheckBox_OverrideLayout.Location = New System.Drawing.Point(481, 338)
        Me.CheckBox_OverrideLayout.Name = "CheckBox_OverrideLayout"
        Me.CheckBox_OverrideLayout.Size = New System.Drawing.Size(101, 17)
        Me.CheckBox_OverrideLayout.TabIndex = 47
        Me.CheckBox_OverrideLayout.Text = "Override Layout"
        Me.CheckBox_OverrideLayout.UseVisualStyleBackColor = True
        '
        'Panel_OverrideLayout
        '
        Me.Panel_OverrideLayout.Controls.Add(Me.Button_OverrideLayoutReset)
        Me.Panel_OverrideLayout.Controls.Add(Me.Label6)
        Me.Panel_OverrideLayout.Controls.Add(Me.ComboBox_LayoutOptions)
        Me.Panel_OverrideLayout.Enabled = False
        Me.Panel_OverrideLayout.Location = New System.Drawing.Point(479, 353)
        Me.Panel_OverrideLayout.Name = "Panel_OverrideLayout"
        Me.Panel_OverrideLayout.Size = New System.Drawing.Size(168, 50)
        Me.Panel_OverrideLayout.TabIndex = 48
        '
        'Button_OverrideLayoutReset
        '
        Me.Button_OverrideLayoutReset.Location = New System.Drawing.Point(93, 3)
        Me.Button_OverrideLayoutReset.Name = "Button_OverrideLayoutReset"
        Me.Button_OverrideLayoutReset.Size = New System.Drawing.Size(75, 23)
        Me.Button_OverrideLayoutReset.TabIndex = 58
        Me.Button_OverrideLayoutReset.Text = "Reset"
        Me.Button_OverrideLayoutReset.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(2, 9)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(42, 13)
        Me.Label6.TabIndex = 44
        Me.Label6.Text = "Layout:"
        '
        'Button_CompareToMessageBox
        '
        Me.Button_CompareToMessageBox.Location = New System.Drawing.Point(16, 180)
        Me.Button_CompareToMessageBox.Name = "Button_CompareToMessageBox"
        Me.Button_CompareToMessageBox.Size = New System.Drawing.Size(157, 23)
        Me.Button_CompareToMessageBox.TabIndex = 49
        Me.Button_CompareToMessageBox.Text = "Compare to MessageBox"
        Me.Button_CompareToMessageBox.UseVisualStyleBackColor = True
        '
        'CheckBox_ShowPicture
        '
        Me.CheckBox_ShowPicture.AutoSize = True
        Me.CheckBox_ShowPicture.Location = New System.Drawing.Point(674, 128)
        Me.CheckBox_ShowPicture.Name = "CheckBox_ShowPicture"
        Me.CheckBox_ShowPicture.Size = New System.Drawing.Size(89, 17)
        Me.CheckBox_ShowPicture.TabIndex = 50
        Me.CheckBox_ShowPicture.Text = "Show Picture"
        Me.CheckBox_ShowPicture.UseVisualStyleBackColor = True
        '
        'Button_BrowseForPicture
        '
        Me.Button_BrowseForPicture.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_BrowseForPicture.Location = New System.Drawing.Point(920, 385)
        Me.Button_BrowseForPicture.Name = "Button_BrowseForPicture"
        Me.Button_BrowseForPicture.Size = New System.Drawing.Size(56, 23)
        Me.Button_BrowseForPicture.TabIndex = 51
        Me.Button_BrowseForPicture.Text = "Browse"
        Me.Button_BrowseForPicture.UseVisualStyleBackColor = True
        '
        'Button_ResetPicture
        '
        Me.Button_ResetPicture.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_ResetPicture.Location = New System.Drawing.Point(976, 385)
        Me.Button_ResetPicture.Name = "Button_ResetPicture"
        Me.Button_ResetPicture.Size = New System.Drawing.Size(56, 23)
        Me.Button_ResetPicture.TabIndex = 52
        Me.Button_ResetPicture.Text = "Reset"
        Me.Button_ResetPicture.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(757, 13)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(36, 13)
        Me.Label5.TabIndex = 54
        Me.Label5.Text = "Icons:"
        '
        'ComboBox_IconOptions
        '
        Me.ComboBox_IconOptions.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_IconOptions.FormattingEnabled = True
        Me.ComboBox_IconOptions.Items.AddRange(New Object() {"OK", "OK, Cancel ", "OK, No", "OK, No, Cancel", "Yes, No", "Yes, No, Cancel", "Cancel, Continue", "No, Continue"})
        Me.ComboBox_IconOptions.Location = New System.Drawing.Point(760, 32)
        Me.ComboBox_IconOptions.Name = "ComboBox_IconOptions"
        Me.ComboBox_IconOptions.Size = New System.Drawing.Size(213, 21)
        Me.ComboBox_IconOptions.TabIndex = 53
        '
        'Button_Icon_Reset
        '
        Me.Button_Icon_Reset.Location = New System.Drawing.Point(918, 55)
        Me.Button_Icon_Reset.Name = "Button_Icon_Reset"
        Me.Button_Icon_Reset.Size = New System.Drawing.Size(56, 23)
        Me.Button_Icon_Reset.TabIndex = 56
        Me.Button_Icon_Reset.Text = "Reset"
        Me.Button_Icon_Reset.UseVisualStyleBackColor = True
        '
        'Button_Icon_Browse
        '
        Me.Button_Icon_Browse.Location = New System.Drawing.Point(862, 55)
        Me.Button_Icon_Browse.Name = "Button_Icon_Browse"
        Me.Button_Icon_Browse.Size = New System.Drawing.Size(56, 23)
        Me.Button_Icon_Browse.TabIndex = 55
        Me.Button_Icon_Browse.Text = "Browse"
        Me.Button_Icon_Browse.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.Button_SimpleMsgNew)
        Me.GroupBox1.Controls.Add(Me.Button_SimpleMsg)
        Me.GroupBox1.Controls.Add(Me.Button_ShowMsgNew)
        Me.GroupBox1.Controls.Add(Me.Button_Quit)
        Me.GroupBox1.Controls.Add(Me.Button_ShowMsg)
        Me.GroupBox1.Controls.Add(Me.Button_CompareToMessageBox)
        Me.GroupBox1.Location = New System.Drawing.Point(659, 427)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(371, 225)
        Me.GroupBox1.TabIndex = 57
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Controls"
        '
        'Button_SimpleMsgNew
        '
        Me.Button_SimpleMsgNew.Location = New System.Drawing.Point(179, 61)
        Me.Button_SimpleMsgNew.Name = "Button_SimpleMsgNew"
        Me.Button_SimpleMsgNew.Size = New System.Drawing.Size(75, 23)
        Me.Button_SimpleMsgNew.TabIndex = 52
        Me.Button_SimpleMsgNew.Text = "Simple NEW"
        Me.Button_SimpleMsgNew.UseVisualStyleBackColor = True
        '
        'Button_SimpleMsg
        '
        Me.Button_SimpleMsg.Location = New System.Drawing.Point(179, 32)
        Me.Button_SimpleMsg.Name = "Button_SimpleMsg"
        Me.Button_SimpleMsg.Size = New System.Drawing.Size(75, 23)
        Me.Button_SimpleMsg.TabIndex = 51
        Me.Button_SimpleMsg.Text = "Simple Msg"
        Me.Button_SimpleMsg.UseVisualStyleBackColor = True
        '
        'Button_ShowMsgNew
        '
        Me.Button_ShowMsgNew.Location = New System.Drawing.Point(16, 61)
        Me.Button_ShowMsgNew.Name = "Button_ShowMsgNew"
        Me.Button_ShowMsgNew.Size = New System.Drawing.Size(157, 23)
        Me.Button_ShowMsgNew.TabIndex = 50
        Me.Button_ShowMsgNew.Text = "NEW Instance"
        Me.Button_ShowMsgNew.UseVisualStyleBackColor = True
        '
        'CheckBox_CustomTheme
        '
        Me.CheckBox_CustomTheme.AutoSize = True
        Me.CheckBox_CustomTheme.Location = New System.Drawing.Point(9, 519)
        Me.CheckBox_CustomTheme.Name = "CheckBox_CustomTheme"
        Me.CheckBox_CustomTheme.Size = New System.Drawing.Size(97, 17)
        Me.CheckBox_CustomTheme.TabIndex = 58
        Me.CheckBox_CustomTheme.Text = "Custom Theme"
        Me.CheckBox_CustomTheme.UseVisualStyleBackColor = True
        '
        'Panel_Theme
        '
        Me.Panel_Theme.Controls.Add(Me.ComboBox_Theme_Presets)
        Me.Panel_Theme.Controls.Add(Me.Label19)
        Me.Panel_Theme.Controls.Add(Me.Button_Theme_Reset)
        Me.Panel_Theme.Controls.Add(Me.ComboBox_Theme_ButtonStyles)
        Me.Panel_Theme.Controls.Add(Me.Label18)
        Me.Panel_Theme.Controls.Add(Me.PictureBox_Theme_ButtonFontColour)
        Me.Panel_Theme.Controls.Add(Me.Label17)
        Me.Panel_Theme.Controls.Add(Me.PictureBox_Theme_ButtonColour)
        Me.Panel_Theme.Controls.Add(Me.Label16)
        Me.Panel_Theme.Controls.Add(Me.PictureBox_Theme_FooterColour)
        Me.Panel_Theme.Controls.Add(Me.Label15)
        Me.Panel_Theme.Controls.Add(Me.PictureBox_Theme_FontColour)
        Me.Panel_Theme.Controls.Add(Me.Label14)
        Me.Panel_Theme.Controls.Add(Me.PictureBox_Theme_BackColour)
        Me.Panel_Theme.Controls.Add(Me.Label13)
        Me.Panel_Theme.Enabled = False
        Me.Panel_Theme.Location = New System.Drawing.Point(7, 531)
        Me.Panel_Theme.Name = "Panel_Theme"
        Me.Panel_Theme.Size = New System.Drawing.Size(364, 85)
        Me.Panel_Theme.TabIndex = 59
        '
        'ComboBox_Theme_Presets
        '
        Me.ComboBox_Theme_Presets.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_Theme_Presets.FormattingEnabled = True
        Me.ComboBox_Theme_Presets.Items.AddRange(New Object() {"Default", "Light", "Dark"})
        Me.ComboBox_Theme_Presets.Location = New System.Drawing.Point(260, 11)
        Me.ComboBox_Theme_Presets.Name = "ComboBox_Theme_Presets"
        Me.ComboBox_Theme_Presets.Size = New System.Drawing.Size(104, 21)
        Me.ComboBox_Theme_Presets.TabIndex = 57
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(213, 15)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(45, 13)
        Me.Label19.TabIndex = 56
        Me.Label19.Text = "Presets:"
        '
        'Button_Theme_Reset
        '
        Me.Button_Theme_Reset.Location = New System.Drawing.Point(1, 9)
        Me.Button_Theme_Reset.Name = "Button_Theme_Reset"
        Me.Button_Theme_Reset.Size = New System.Drawing.Size(80, 23)
        Me.Button_Theme_Reset.TabIndex = 50
        Me.Button_Theme_Reset.Text = "Reset"
        Me.Button_Theme_Reset.UseVisualStyleBackColor = True
        '
        'ComboBox_Theme_ButtonStyles
        '
        Me.ComboBox_Theme_ButtonStyles.FormattingEnabled = True
        Me.ComboBox_Theme_ButtonStyles.Items.AddRange(New Object() {"Flat", "Popup", "Standard", "System"})
        Me.ComboBox_Theme_ButtonStyles.Location = New System.Drawing.Point(260, 61)
        Me.ComboBox_Theme_ButtonStyles.Name = "ComboBox_Theme_ButtonStyles"
        Me.ComboBox_Theme_ButtonStyles.Size = New System.Drawing.Size(104, 21)
        Me.ComboBox_Theme_ButtonStyles.TabIndex = 55
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(226, 64)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(33, 13)
        Me.Label18.TabIndex = 54
        Me.Label18.Text = "Style:"
        '
        'PictureBox_Theme_ButtonFontColour
        '
        Me.PictureBox_Theme_ButtonFontColour.BackColor = System.Drawing.Color.Black
        Me.PictureBox_Theme_ButtonFontColour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox_Theme_ButtonFontColour.Location = New System.Drawing.Point(199, 60)
        Me.PictureBox_Theme_ButtonFontColour.Name = "PictureBox_Theme_ButtonFontColour"
        Me.PictureBox_Theme_ButtonFontColour.Size = New System.Drawing.Size(20, 20)
        Me.PictureBox_Theme_ButtonFontColour.TabIndex = 53
        Me.PictureBox_Theme_ButtonFontColour.TabStop = False
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(103, 64)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(95, 13)
        Me.Label17.TabIndex = 52
        Me.Label17.Text = "Button Font Colour"
        '
        'PictureBox_Theme_ButtonColour
        '
        Me.PictureBox_Theme_ButtonColour.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.PictureBox_Theme_ButtonColour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox_Theme_ButtonColour.Location = New System.Drawing.Point(344, 36)
        Me.PictureBox_Theme_ButtonColour.Name = "PictureBox_Theme_ButtonColour"
        Me.PictureBox_Theme_ButtonColour.Size = New System.Drawing.Size(20, 20)
        Me.PictureBox_Theme_ButtonColour.TabIndex = 51
        Me.PictureBox_Theme_ButtonColour.TabStop = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(270, 40)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(71, 13)
        Me.Label16.TabIndex = 50
        Me.Label16.Text = "Button Colour"
        '
        'PictureBox_Theme_FooterColour
        '
        Me.PictureBox_Theme_FooterColour.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.PictureBox_Theme_FooterColour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox_Theme_FooterColour.Location = New System.Drawing.Point(75, 60)
        Me.PictureBox_Theme_FooterColour.Name = "PictureBox_Theme_FooterColour"
        Me.PictureBox_Theme_FooterColour.Size = New System.Drawing.Size(20, 20)
        Me.PictureBox_Theme_FooterColour.TabIndex = 49
        Me.PictureBox_Theme_FooterColour.TabStop = False
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(3, 64)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(70, 13)
        Me.Label15.TabIndex = 48
        Me.Label15.Text = "Footer Colour"
        '
        'PictureBox_Theme_FontColour
        '
        Me.PictureBox_Theme_FontColour.BackColor = System.Drawing.Color.Black
        Me.PictureBox_Theme_FontColour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox_Theme_FontColour.Location = New System.Drawing.Point(199, 37)
        Me.PictureBox_Theme_FontColour.Name = "PictureBox_Theme_FontColour"
        Me.PictureBox_Theme_FontColour.Size = New System.Drawing.Size(20, 20)
        Me.PictureBox_Theme_FontColour.TabIndex = 47
        Me.PictureBox_Theme_FontColour.TabStop = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(135, 41)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(61, 13)
        Me.Label14.TabIndex = 46
        Me.Label14.Text = "Font Colour"
        '
        'PictureBox_Theme_BackColour
        '
        Me.PictureBox_Theme_BackColour.BackColor = System.Drawing.Color.White
        Me.PictureBox_Theme_BackColour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox_Theme_BackColour.Location = New System.Drawing.Point(75, 36)
        Me.PictureBox_Theme_BackColour.Name = "PictureBox_Theme_BackColour"
        Me.PictureBox_Theme_BackColour.Size = New System.Drawing.Size(20, 20)
        Me.PictureBox_Theme_BackColour.TabIndex = 45
        Me.PictureBox_Theme_BackColour.TabStop = False
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(3, 40)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(65, 13)
        Me.Label13.TabIndex = 44
        Me.Label13.Text = "Back Colour"
        '
        'CheckBox_OverrideSizePosition
        '
        Me.CheckBox_OverrideSizePosition.AutoSize = True
        Me.CheckBox_OverrideSizePosition.Location = New System.Drawing.Point(479, 430)
        Me.CheckBox_OverrideSizePosition.Name = "CheckBox_OverrideSizePosition"
        Me.CheckBox_OverrideSizePosition.Size = New System.Drawing.Size(138, 17)
        Me.CheckBox_OverrideSizePosition.TabIndex = 60
        Me.CheckBox_OverrideSizePosition.Text = "Override Size && Position"
        Me.CheckBox_OverrideSizePosition.UseVisualStyleBackColor = True
        '
        'Panel_OverrideSizePosition
        '
        Me.Panel_OverrideSizePosition.Controls.Add(Me.TextBox_X)
        Me.Panel_OverrideSizePosition.Controls.Add(Me.Label9)
        Me.Panel_OverrideSizePosition.Controls.Add(Me.Label10)
        Me.Panel_OverrideSizePosition.Controls.Add(Me.Label8)
        Me.Panel_OverrideSizePosition.Controls.Add(Me.TextBox_Height)
        Me.Panel_OverrideSizePosition.Controls.Add(Me.TextBox_Y)
        Me.Panel_OverrideSizePosition.Controls.Add(Me.Label7)
        Me.Panel_OverrideSizePosition.Controls.Add(Me.TextBox_Width)
        Me.Panel_OverrideSizePosition.Enabled = False
        Me.Panel_OverrideSizePosition.Location = New System.Drawing.Point(476, 446)
        Me.Panel_OverrideSizePosition.Name = "Panel_OverrideSizePosition"
        Me.Panel_OverrideSizePosition.Size = New System.Drawing.Size(161, 50)
        Me.Panel_OverrideSizePosition.TabIndex = 50
        '
        'CheckBox_TimedMessage
        '
        Me.CheckBox_TimedMessage.AutoSize = True
        Me.CheckBox_TimedMessage.Location = New System.Drawing.Point(10, 375)
        Me.CheckBox_TimedMessage.Name = "CheckBox_TimedMessage"
        Me.CheckBox_TimedMessage.Size = New System.Drawing.Size(101, 17)
        Me.CheckBox_TimedMessage.TabIndex = 61
        Me.CheckBox_TimedMessage.Text = "Timed Message"
        Me.CheckBox_TimedMessage.UseVisualStyleBackColor = True
        '
        'Panel_TimedDuration
        '
        Me.Panel_TimedDuration.Controls.Add(Me.Label20)
        Me.Panel_TimedDuration.Controls.Add(Me.TextBox_Duration)
        Me.Panel_TimedDuration.Enabled = False
        Me.Panel_TimedDuration.Location = New System.Drawing.Point(111, 372)
        Me.Panel_TimedDuration.Name = "Panel_TimedDuration"
        Me.Panel_TimedDuration.Size = New System.Drawing.Size(125, 25)
        Me.Panel_TimedDuration.TabIndex = 62
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(3, 4)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(69, 13)
        Me.Label20.TabIndex = 39
        Me.Label20.Text = "Duration (ms)"
        '
        'TextBox_Duration
        '
        Me.TextBox_Duration.Location = New System.Drawing.Point(71, 1)
        Me.TextBox_Duration.Name = "TextBox_Duration"
        Me.TextBox_Duration.Size = New System.Drawing.Size(50, 20)
        Me.TextBox_Duration.TabIndex = 38
        Me.TextBox_Duration.Text = "2000"
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.Button_Code_Copy)
        Me.Panel1.Controls.Add(Me.Button_Code_Clear)
        Me.Panel1.Controls.Add(Me.Label21)
        Me.Panel1.Controls.Add(Me.TextBox_ActualCode)
        Me.Panel1.Location = New System.Drawing.Point(14, 656)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1017, 49)
        Me.Panel1.TabIndex = 63
        '
        'Button_Code_Copy
        '
        Me.Button_Code_Copy.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Code_Copy.Location = New System.Drawing.Point(939, 23)
        Me.Button_Code_Copy.Name = "Button_Code_Copy"
        Me.Button_Code_Copy.Size = New System.Drawing.Size(75, 23)
        Me.Button_Code_Copy.TabIndex = 47
        Me.Button_Code_Copy.Text = "Copy"
        Me.Button_Code_Copy.UseVisualStyleBackColor = True
        '
        'Button_Code_Clear
        '
        Me.Button_Code_Clear.Location = New System.Drawing.Point(86, 3)
        Me.Button_Code_Clear.Name = "Button_Code_Clear"
        Me.Button_Code_Clear.Size = New System.Drawing.Size(75, 23)
        Me.Button_Code_Clear.TabIndex = 46
        Me.Button_Code_Clear.Text = "Clear"
        Me.Button_Code_Clear.UseVisualStyleBackColor = True
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(3, 10)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(78, 13)
        Me.Label21.TabIndex = 45
        Me.Label21.Text = "Code Example:"
        '
        'TextBox_ActualCode
        '
        Me.TextBox_ActualCode.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_ActualCode.Location = New System.Drawing.Point(1, 26)
        Me.TextBox_ActualCode.Name = "TextBox_ActualCode"
        Me.TextBox_ActualCode.ReadOnly = True
        Me.TextBox_ActualCode.Size = New System.Drawing.Size(934, 20)
        Me.TextBox_ActualCode.TabIndex = 0
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(187, 320)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(75, 13)
        Me.Label22.TabIndex = 65
        Me.Label22.Text = "Default Button"
        '
        'ComboBox_DefaultButton
        '
        Me.ComboBox_DefaultButton.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_DefaultButton.FormattingEnabled = True
        Me.ComboBox_DefaultButton.Items.AddRange(New Object() {"OK", "Cancel ", "No", "Yes", "Continue"})
        Me.ComboBox_DefaultButton.Location = New System.Drawing.Point(268, 316)
        Me.ComboBox_DefaultButton.Name = "ComboBox_DefaultButton"
        Me.ComboBox_DefaultButton.Size = New System.Drawing.Size(77, 21)
        Me.ComboBox_DefaultButton.TabIndex = 64
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.TextBox_RTF_Message)
        Me.Panel2.Location = New System.Drawing.Point(352, 79)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(296, 84)
        Me.Panel2.TabIndex = 66
        '
        'TextBox_RTF_Message
        '
        Me.TextBox_RTF_Message.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox_RTF_Message.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox_RTF_Message.Location = New System.Drawing.Point(0, 0)
        Me.TextBox_RTF_Message.Multiline = True
        Me.TextBox_RTF_Message.Name = "TextBox_RTF_Message"
        Me.TextBox_RTF_Message.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox_RTF_Message.Size = New System.Drawing.Size(294, 82)
        Me.TextBox_RTF_Message.TabIndex = 0
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.TextBox_RTF_Heading)
        Me.Panel3.Location = New System.Drawing.Point(352, 189)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(296, 49)
        Me.Panel3.TabIndex = 67
        '
        'TextBox_RTF_Heading
        '
        Me.TextBox_RTF_Heading.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox_RTF_Heading.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox_RTF_Heading.Location = New System.Drawing.Point(0, 0)
        Me.TextBox_RTF_Heading.Multiline = True
        Me.TextBox_RTF_Heading.Name = "TextBox_RTF_Heading"
        Me.TextBox_RTF_Heading.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox_RTF_Heading.Size = New System.Drawing.Size(294, 47)
        Me.TextBox_RTF_Heading.TabIndex = 0
        '
        'Panel4
        '
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.TextBox_RTF_Footer)
        Me.Panel4.Location = New System.Drawing.Point(352, 262)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(295, 49)
        Me.Panel4.TabIndex = 68
        '
        'TextBox_RTF_Footer
        '
        Me.TextBox_RTF_Footer.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox_RTF_Footer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox_RTF_Footer.Location = New System.Drawing.Point(0, 0)
        Me.TextBox_RTF_Footer.Multiline = True
        Me.TextBox_RTF_Footer.Name = "TextBox_RTF_Footer"
        Me.TextBox_RTF_Footer.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox_RTF_Footer.Size = New System.Drawing.Size(293, 47)
        Me.TextBox_RTF_Footer.TabIndex = 0
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(350, 63)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(28, 13)
        Me.Label23.TabIndex = 69
        Me.Label23.Text = "RTF"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(351, 174)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(28, 13)
        Me.Label24.TabIndex = 70
        Me.Label24.Text = "RTF"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(351, 246)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(28, 13)
        Me.Label25.TabIndex = 71
        Me.Label25.Text = "RTF"
        '
        'Button_RTF_RefreshMessage
        '
        Me.Button_RTF_RefreshMessage.Location = New System.Drawing.Point(384, 55)
        Me.Button_RTF_RefreshMessage.Name = "Button_RTF_RefreshMessage"
        Me.Button_RTF_RefreshMessage.Size = New System.Drawing.Size(59, 23)
        Me.Button_RTF_RefreshMessage.TabIndex = 72
        Me.Button_RTF_RefreshMessage.Text = "Refresh"
        Me.Button_RTF_RefreshMessage.UseVisualStyleBackColor = True
        '
        'Button_RTF_RefreshHeading
        '
        Me.Button_RTF_RefreshHeading.Location = New System.Drawing.Point(384, 165)
        Me.Button_RTF_RefreshHeading.Name = "Button_RTF_RefreshHeading"
        Me.Button_RTF_RefreshHeading.Size = New System.Drawing.Size(59, 23)
        Me.Button_RTF_RefreshHeading.TabIndex = 73
        Me.Button_RTF_RefreshHeading.Text = "Refresh"
        Me.Button_RTF_RefreshHeading.UseVisualStyleBackColor = True
        '
        'Button_RTF_RefreshFooter
        '
        Me.Button_RTF_RefreshFooter.Location = New System.Drawing.Point(384, 238)
        Me.Button_RTF_RefreshFooter.Name = "Button_RTF_RefreshFooter"
        Me.Button_RTF_RefreshFooter.Size = New System.Drawing.Size(59, 23)
        Me.Button_RTF_RefreshFooter.TabIndex = 74
        Me.Button_RTF_RefreshFooter.Text = "Refresh"
        Me.Button_RTF_RefreshFooter.UseVisualStyleBackColor = True
        '
        'Button_RTF_ClearMessage
        '
        Me.Button_RTF_ClearMessage.Location = New System.Drawing.Point(443, 55)
        Me.Button_RTF_ClearMessage.Name = "Button_RTF_ClearMessage"
        Me.Button_RTF_ClearMessage.Size = New System.Drawing.Size(59, 23)
        Me.Button_RTF_ClearMessage.TabIndex = 75
        Me.Button_RTF_ClearMessage.Text = "Clear"
        Me.Button_RTF_ClearMessage.UseVisualStyleBackColor = True
        '
        'Button_RTF_ClearHeading
        '
        Me.Button_RTF_ClearHeading.Location = New System.Drawing.Point(444, 165)
        Me.Button_RTF_ClearHeading.Name = "Button_RTF_ClearHeading"
        Me.Button_RTF_ClearHeading.Size = New System.Drawing.Size(59, 23)
        Me.Button_RTF_ClearHeading.TabIndex = 76
        Me.Button_RTF_ClearHeading.Text = "Clear"
        Me.Button_RTF_ClearHeading.UseVisualStyleBackColor = True
        '
        'Button_RTF_ClearFooter
        '
        Me.Button_RTF_ClearFooter.Location = New System.Drawing.Point(444, 238)
        Me.Button_RTF_ClearFooter.Name = "Button_RTF_ClearFooter"
        Me.Button_RTF_ClearFooter.Size = New System.Drawing.Size(59, 23)
        Me.Button_RTF_ClearFooter.TabIndex = 77
        Me.Button_RTF_ClearFooter.Text = "Clear"
        Me.Button_RTF_ClearFooter.UseVisualStyleBackColor = True
        '
        'Button_Form1_MessageClear
        '
        Me.Button_Form1_MessageClear.Location = New System.Drawing.Point(55, 56)
        Me.Button_Form1_MessageClear.Name = "Button_Form1_MessageClear"
        Me.Button_Form1_MessageClear.Size = New System.Drawing.Size(59, 23)
        Me.Button_Form1_MessageClear.TabIndex = 78
        Me.Button_Form1_MessageClear.Text = "Clear"
        Me.Button_Form1_MessageClear.UseVisualStyleBackColor = True
        '
        'Button_Form1_HeadingClear
        '
        Me.Button_Form1_HeadingClear.Location = New System.Drawing.Point(55, 166)
        Me.Button_Form1_HeadingClear.Name = "Button_Form1_HeadingClear"
        Me.Button_Form1_HeadingClear.Size = New System.Drawing.Size(59, 23)
        Me.Button_Form1_HeadingClear.TabIndex = 79
        Me.Button_Form1_HeadingClear.Text = "Clear"
        Me.Button_Form1_HeadingClear.UseVisualStyleBackColor = True
        '
        'Button_Form1_FooterClear
        '
        Me.Button_Form1_FooterClear.Location = New System.Drawing.Point(55, 239)
        Me.Button_Form1_FooterClear.Name = "Button_Form1_FooterClear"
        Me.Button_Form1_FooterClear.Size = New System.Drawing.Size(59, 23)
        Me.Button_Form1_FooterClear.TabIndex = 80
        Me.Button_Form1_FooterClear.Text = "Clear"
        Me.Button_Form1_FooterClear.UseVisualStyleBackColor = True
        '
        'Button_Form1_HeadingAsPlain
        '
        Me.Button_Form1_HeadingAsPlain.Location = New System.Drawing.Point(120, 166)
        Me.Button_Form1_HeadingAsPlain.Name = "Button_Form1_HeadingAsPlain"
        Me.Button_Form1_HeadingAsPlain.Size = New System.Drawing.Size(59, 23)
        Me.Button_Form1_HeadingAsPlain.TabIndex = 81
        Me.Button_Form1_HeadingAsPlain.Text = "As Plain"
        Me.Button_Form1_HeadingAsPlain.UseVisualStyleBackColor = True
        '
        'Button_Form1_MessageAsPlain
        '
        Me.Button_Form1_MessageAsPlain.Location = New System.Drawing.Point(120, 56)
        Me.Button_Form1_MessageAsPlain.Name = "Button_Form1_MessageAsPlain"
        Me.Button_Form1_MessageAsPlain.Size = New System.Drawing.Size(59, 23)
        Me.Button_Form1_MessageAsPlain.TabIndex = 82
        Me.Button_Form1_MessageAsPlain.Text = "As Plain"
        Me.Button_Form1_MessageAsPlain.UseVisualStyleBackColor = True
        '
        'Button_Form1_FooterAsPlain
        '
        Me.Button_Form1_FooterAsPlain.Location = New System.Drawing.Point(120, 239)
        Me.Button_Form1_FooterAsPlain.Name = "Button_Form1_FooterAsPlain"
        Me.Button_Form1_FooterAsPlain.Size = New System.Drawing.Size(59, 23)
        Me.Button_Form1_FooterAsPlain.TabIndex = 83
        Me.Button_Form1_FooterAsPlain.Text = "As Plain"
        Me.Button_Form1_FooterAsPlain.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1042, 711)
        Me.Controls.Add(Me.Button_Form1_FooterAsPlain)
        Me.Controls.Add(Me.Button_Form1_MessageAsPlain)
        Me.Controls.Add(Me.Button_Form1_HeadingAsPlain)
        Me.Controls.Add(Me.Button_Form1_FooterClear)
        Me.Controls.Add(Me.Button_Form1_HeadingClear)
        Me.Controls.Add(Me.Button_Form1_MessageClear)
        Me.Controls.Add(Me.Button_RTF_ClearFooter)
        Me.Controls.Add(Me.Button_RTF_ClearHeading)
        Me.Controls.Add(Me.Button_RTF_ClearMessage)
        Me.Controls.Add(Me.Button_RTF_RefreshFooter)
        Me.Controls.Add(Me.Button_RTF_RefreshHeading)
        Me.Controls.Add(Me.Button_RTF_RefreshMessage)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.ComboBox_DefaultButton)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel_TimedDuration)
        Me.Controls.Add(Me.CheckBox_TimedMessage)
        Me.Controls.Add(Me.CheckBox_OverrideSizePosition)
        Me.Controls.Add(Me.Panel_OverrideSizePosition)
        Me.Controls.Add(Me.CheckBox_CustomTheme)
        Me.Controls.Add(Me.Panel_Theme)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Button_Icon_Reset)
        Me.Controls.Add(Me.Button_Icon_Browse)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.ComboBox_IconOptions)
        Me.Controls.Add(Me.Button_ResetPicture)
        Me.Controls.Add(Me.Button_BrowseForPicture)
        Me.Controls.Add(Me.CheckBox_ShowPicture)
        Me.Controls.Add(Me.CheckBox_OverrideLayout)
        Me.Controls.Add(Me.Panel_OverrideLayout)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Panel_HelpFunction)
        Me.Controls.Add(Me.PictureBox_PreviewIcon)
        Me.Controls.Add(Me.CheckBox_ShowIcon)
        Me.Controls.Add(Me.PictureBox_PreviewPicture)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TextBox_Form1_Title)
        Me.Controls.Add(Me.CheckBox_ShowHelpButton)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.RichTextBox_Form1_Footer)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.RichTextBox_Form1_Message)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.RichTextBox_Form1_Heading)
        Me.Controls.Add(Me.ComboBox_ButtonOptions)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(1058, 750)
        Me.Name = "Form1"
        Me.Text = "Demo - Test the Msg Class"
        CType(Me.PictureBox_PreviewPicture, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox_PreviewIcon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel_HelpFunction.ResumeLayout(False)
        Me.Panel_HelpFunction.PerformLayout()
        Me.Panel_OverrideLayout.ResumeLayout(False)
        Me.Panel_OverrideLayout.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.Panel_Theme.ResumeLayout(False)
        Me.Panel_Theme.PerformLayout()
        CType(Me.PictureBox_Theme_ButtonFontColour, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox_Theme_ButtonColour, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox_Theme_FooterColour, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox_Theme_FontColour, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox_Theme_BackColour, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel_OverrideSizePosition.ResumeLayout(False)
        Me.Panel_OverrideSizePosition.PerformLayout()
        Me.Panel_TimedDuration.ResumeLayout(False)
        Me.Panel_TimedDuration.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button_Quit As Button
    Friend WithEvents ComboBox_ButtonOptions As ComboBox
    Friend WithEvents ComboBox_LayoutOptions As ComboBox
    Friend WithEvents RichTextBox_Form1_Heading As RichTextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents RichTextBox_Form1_Message As RichTextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents RichTextBox_Form1_Footer As RichTextBox
    Friend WithEvents TextBox_Form1_Title As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents PictureBox_PreviewPicture As PictureBox
    Friend WithEvents CheckBox_ShowIcon As CheckBox
    Friend WithEvents PictureBox_PreviewIcon As PictureBox
    Friend WithEvents Label7 As Label
    Friend WithEvents TextBox_X As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents TextBox_Y As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents TextBox_Height As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents TextBox_Width As TextBox
    Friend WithEvents Button_ShowMsg As Button
    Friend WithEvents CheckBox_ShowHelpButton As CheckBox
    Friend WithEvents ComboBox_HelpFunction As ComboBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Panel_HelpFunction As Panel
    Friend WithEvents Label12 As Label
    Friend WithEvents CheckBox_OverrideLayout As CheckBox
    Friend WithEvents Panel_OverrideLayout As Panel
    Friend WithEvents Label6 As Label
    Friend WithEvents Button_CompareToMessageBox As Button
    Friend WithEvents CheckBox_ShowPicture As CheckBox
    Friend WithEvents Button_BrowseForPicture As Button
    Friend WithEvents Button_ResetPicture As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents ComboBox_IconOptions As ComboBox
    Friend WithEvents Button_Icon_Reset As Button
    Friend WithEvents Button_Icon_Browse As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents CheckBox_CustomTheme As CheckBox
    Friend WithEvents Panel_Theme As Panel
    Friend WithEvents Label13 As Label
    Friend WithEvents PictureBox_Theme_FontColour As PictureBox
    Friend WithEvents Label14 As Label
    Friend WithEvents PictureBox_Theme_BackColour As PictureBox
    Friend WithEvents PictureBox_Theme_ButtonFontColour As PictureBox
    Friend WithEvents Label17 As Label
    Friend WithEvents PictureBox_Theme_ButtonColour As PictureBox
    Friend WithEvents Label16 As Label
    Friend WithEvents PictureBox_Theme_FooterColour As PictureBox
    Friend WithEvents Label15 As Label
    Friend WithEvents ComboBox_Theme_ButtonStyles As ComboBox
    Friend WithEvents Label18 As Label
    Friend WithEvents ComboBox_Theme_Presets As ComboBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Button_Theme_Reset As Button
    Friend WithEvents Button_OverrideLayoutReset As Button
    Friend WithEvents CheckBox_OverrideSizePosition As CheckBox
    Friend WithEvents Panel_OverrideSizePosition As Panel
    Friend WithEvents Button_ShowMsgNew As Button
    Friend WithEvents CheckBox_TimedMessage As CheckBox
    Friend WithEvents Panel_TimedDuration As Panel
    Friend WithEvents Label20 As Label
    Friend WithEvents TextBox_Duration As TextBox
    Friend WithEvents Button_SimpleMsg As Button
    Friend WithEvents Button_SimpleMsgNew As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents TextBox_ActualCode As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents Button_Code_Clear As Button
    Friend WithEvents Button_Code_Copy As Button
    Friend WithEvents Label22 As Label
    Friend WithEvents ComboBox_DefaultButton As ComboBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents TextBox_RTF_Message As TextBox
    Friend WithEvents Panel3 As Panel
    Friend WithEvents TextBox_RTF_Heading As TextBox
    Friend WithEvents Panel4 As Panel
    Friend WithEvents TextBox_RTF_Footer As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Button_RTF_RefreshMessage As Button
    Friend WithEvents Button_RTF_RefreshHeading As Button
    Friend WithEvents Button_RTF_RefreshFooter As Button
    Friend WithEvents Button_RTF_ClearMessage As Button
    Friend WithEvents Button_RTF_ClearHeading As Button
    Friend WithEvents Button_RTF_ClearFooter As Button
    Friend WithEvents Button_Form1_MessageClear As Button
    Friend WithEvents Button_Form1_HeadingClear As Button
    Friend WithEvents Button_Form1_FooterClear As Button
    Friend WithEvents Button_Form1_HeadingAsPlain As Button
    Friend WithEvents Button_Form1_MessageAsPlain As Button
    Friend WithEvents Button_Form1_FooterAsPlain As Button
End Class
