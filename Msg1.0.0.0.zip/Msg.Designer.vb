﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Msg
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Msg))
        Me.PictureBox_Icon = New System.Windows.Forms.PictureBox()
        Me.Button_Help = New System.Windows.Forms.Button()
        Me.FlowLayoutPanel_ResponseButtons = New System.Windows.Forms.FlowLayoutPanel()
        Me.Button_OK = New System.Windows.Forms.Button()
        Me.Button_Cancel = New System.Windows.Forms.Button()
        Me.Button_No = New System.Windows.Forms.Button()
        Me.Button_Yes = New System.Windows.Forms.Button()
        Me.Button_Continue = New System.Windows.Forms.Button()
        Me.TableLayoutPanel_MsgBox = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel_Heading = New System.Windows.Forms.Panel()
        Me.RichTextBox_Heading = New System.Windows.Forms.RichTextBox()
        Me.Panel_Message = New System.Windows.Forms.Panel()
        Me.RichTextBox_Message = New System.Windows.Forms.RichTextBox()
        Me.PictureBox_Picture = New System.Windows.Forms.PictureBox()
        Me.Panel_Footer = New System.Windows.Forms.Panel()
        Me.RichTextBox_Footer = New System.Windows.Forms.RichTextBox()
        Me.Panel_FormFooter = New System.Windows.Forms.Panel()
        Me.Label_TimerCountdown = New System.Windows.Forms.Label()
        CType(Me.PictureBox_Icon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FlowLayoutPanel_ResponseButtons.SuspendLayout()
        Me.TableLayoutPanel_MsgBox.SuspendLayout()
        Me.Panel_Heading.SuspendLayout()
        Me.Panel_Message.SuspendLayout()
        CType(Me.PictureBox_Picture, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel_Footer.SuspendLayout()
        Me.Panel_FormFooter.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox_Icon
        '
        Me.PictureBox_Icon.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox_Icon.Location = New System.Drawing.Point(3, 3)
        Me.PictureBox_Icon.MaximumSize = New System.Drawing.Size(80, 80)
        Me.PictureBox_Icon.Name = "PictureBox_Icon"
        Me.TableLayoutPanel_MsgBox.SetRowSpan(Me.PictureBox_Icon, 4)
        Me.PictureBox_Icon.Size = New System.Drawing.Size(60, 60)
        Me.PictureBox_Icon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox_Icon.TabIndex = 0
        Me.PictureBox_Icon.TabStop = False
        '
        'Button_Help
        '
        Me.Button_Help.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Button_Help.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Button_Help.Location = New System.Drawing.Point(11, 10)
        Me.Button_Help.Name = "Button_Help"
        Me.Button_Help.Size = New System.Drawing.Size(33, 26)
        Me.Button_Help.TabIndex = 1
        Me.Button_Help.Text = "?"
        Me.Button_Help.UseVisualStyleBackColor = False
        Me.Button_Help.Visible = False
        '
        'FlowLayoutPanel_ResponseButtons
        '
        Me.FlowLayoutPanel_ResponseButtons.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel_ResponseButtons.Controls.Add(Me.Button_OK)
        Me.FlowLayoutPanel_ResponseButtons.Controls.Add(Me.Button_Cancel)
        Me.FlowLayoutPanel_ResponseButtons.Controls.Add(Me.Button_No)
        Me.FlowLayoutPanel_ResponseButtons.Controls.Add(Me.Button_Yes)
        Me.FlowLayoutPanel_ResponseButtons.Controls.Add(Me.Button_Continue)
        Me.FlowLayoutPanel_ResponseButtons.Location = New System.Drawing.Point(72, 10)
        Me.FlowLayoutPanel_ResponseButtons.Name = "FlowLayoutPanel_ResponseButtons"
        Me.FlowLayoutPanel_ResponseButtons.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.FlowLayoutPanel_ResponseButtons.Size = New System.Drawing.Size(282, 26)
        Me.FlowLayoutPanel_ResponseButtons.TabIndex = 2
        '
        'Button_OK
        '
        Me.Button_OK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_OK.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Button_OK.Location = New System.Drawing.Point(216, 0)
        Me.Button_OK.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Button_OK.Name = "Button_OK"
        Me.Button_OK.Size = New System.Drawing.Size(64, 26)
        Me.Button_OK.TabIndex = 0
        Me.Button_OK.Text = "OK"
        Me.Button_OK.UseVisualStyleBackColor = False
        '
        'Button_Cancel
        '
        Me.Button_Cancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Cancel.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Button_Cancel.Location = New System.Drawing.Point(148, 0)
        Me.Button_Cancel.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Button_Cancel.Name = "Button_Cancel"
        Me.Button_Cancel.Size = New System.Drawing.Size(64, 26)
        Me.Button_Cancel.TabIndex = 1
        Me.Button_Cancel.Text = "Cancel"
        Me.Button_Cancel.UseVisualStyleBackColor = False
        Me.Button_Cancel.Visible = False
        '
        'Button_No
        '
        Me.Button_No.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_No.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Button_No.Location = New System.Drawing.Point(80, 0)
        Me.Button_No.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Button_No.Name = "Button_No"
        Me.Button_No.Size = New System.Drawing.Size(64, 26)
        Me.Button_No.TabIndex = 2
        Me.Button_No.Text = "No"
        Me.Button_No.UseVisualStyleBackColor = False
        Me.Button_No.Visible = False
        '
        'Button_Yes
        '
        Me.Button_Yes.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Yes.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Button_Yes.Location = New System.Drawing.Point(12, 0)
        Me.Button_Yes.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Button_Yes.Name = "Button_Yes"
        Me.Button_Yes.Size = New System.Drawing.Size(64, 26)
        Me.Button_Yes.TabIndex = 3
        Me.Button_Yes.Text = "Yes"
        Me.Button_Yes.UseVisualStyleBackColor = False
        Me.Button_Yes.Visible = False
        '
        'Button_Continue
        '
        Me.Button_Continue.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Continue.Location = New System.Drawing.Point(216, 26)
        Me.Button_Continue.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Button_Continue.Name = "Button_Continue"
        Me.Button_Continue.Size = New System.Drawing.Size(64, 26)
        Me.Button_Continue.TabIndex = 4
        Me.Button_Continue.Text = "Continue"
        Me.Button_Continue.UseVisualStyleBackColor = True
        Me.Button_Continue.Visible = False
        '
        'TableLayoutPanel_MsgBox
        '
        Me.TableLayoutPanel_MsgBox.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel_MsgBox.ColumnCount = 2
        Me.TableLayoutPanel_MsgBox.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 66.0!))
        Me.TableLayoutPanel_MsgBox.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel_MsgBox.Controls.Add(Me.Panel_Heading, 1, 0)
        Me.TableLayoutPanel_MsgBox.Controls.Add(Me.Panel_Message, 1, 1)
        Me.TableLayoutPanel_MsgBox.Controls.Add(Me.PictureBox_Icon, 0, 0)
        Me.TableLayoutPanel_MsgBox.Controls.Add(Me.PictureBox_Picture, 1, 2)
        Me.TableLayoutPanel_MsgBox.Controls.Add(Me.Panel_Footer, 1, 3)
        Me.TableLayoutPanel_MsgBox.Location = New System.Drawing.Point(11, 8)
        Me.TableLayoutPanel_MsgBox.Name = "TableLayoutPanel_MsgBox"
        Me.TableLayoutPanel_MsgBox.RowCount = 4
        Me.TableLayoutPanel_MsgBox.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel_MsgBox.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel_MsgBox.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 0!))
        Me.TableLayoutPanel_MsgBox.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 0!))
        Me.TableLayoutPanel_MsgBox.Size = New System.Drawing.Size(338, 90)
        Me.TableLayoutPanel_MsgBox.TabIndex = 0
        '
        'Panel_Heading
        '
        Me.Panel_Heading.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel_Heading.Controls.Add(Me.RichTextBox_Heading)
        Me.Panel_Heading.Location = New System.Drawing.Point(69, 3)
        Me.Panel_Heading.Name = "Panel_Heading"
        Me.Panel_Heading.Size = New System.Drawing.Size(266, 19)
        Me.Panel_Heading.TabIndex = 4
        '
        'RichTextBox_Heading
        '
        Me.RichTextBox_Heading.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RichTextBox_Heading.BackColor = System.Drawing.Color.White
        Me.RichTextBox_Heading.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox_Heading.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.RichTextBox_Heading.Font = New System.Drawing.Font("Segoe UI Variable Small", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox_Heading.ForeColor = System.Drawing.Color.Black
        Me.RichTextBox_Heading.Location = New System.Drawing.Point(3, 0)
        Me.RichTextBox_Heading.Multiline = False
        Me.RichTextBox_Heading.Name = "RichTextBox_Heading"
        Me.RichTextBox_Heading.ReadOnly = True
        Me.RichTextBox_Heading.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox_Heading.Size = New System.Drawing.Size(263, 19)
        Me.RichTextBox_Heading.TabIndex = 0
        Me.RichTextBox_Heading.TabStop = False
        Me.RichTextBox_Heading.Text = "Title text here for a heading "
        Me.RichTextBox_Heading.WordWrap = False
        '
        'Panel_Message
        '
        Me.Panel_Message.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel_Message.Controls.Add(Me.RichTextBox_Message)
        Me.Panel_Message.Location = New System.Drawing.Point(69, 28)
        Me.Panel_Message.Name = "Panel_Message"
        Me.Panel_Message.Size = New System.Drawing.Size(266, 59)
        Me.Panel_Message.TabIndex = 5
        '
        'RichTextBox_Message
        '
        Me.RichTextBox_Message.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RichTextBox_Message.BackColor = System.Drawing.Color.White
        Me.RichTextBox_Message.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox_Message.Font = New System.Drawing.Font("Segoe UI Symbol", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox_Message.ForeColor = System.Drawing.Color.Black
        Me.RichTextBox_Message.Location = New System.Drawing.Point(3, 0)
        Me.RichTextBox_Message.Name = "RichTextBox_Message"
        Me.RichTextBox_Message.ReadOnly = True
        Me.RichTextBox_Message.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical
        Me.RichTextBox_Message.Size = New System.Drawing.Size(268, 59)
        Me.RichTextBox_Message.TabIndex = 0
        Me.RichTextBox_Message.Text = resources.GetString("RichTextBox_Message.Text")
        '
        'PictureBox_Picture
        '
        Me.PictureBox_Picture.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox_Picture.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox_Picture.Location = New System.Drawing.Point(69, 93)
        Me.PictureBox_Picture.Name = "PictureBox_Picture"
        Me.PictureBox_Picture.Size = New System.Drawing.Size(266, 1)
        Me.PictureBox_Picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox_Picture.TabIndex = 7
        Me.PictureBox_Picture.TabStop = False
        '
        'Panel_Footer
        '
        Me.Panel_Footer.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel_Footer.Controls.Add(Me.RichTextBox_Footer)
        Me.Panel_Footer.Location = New System.Drawing.Point(69, 93)
        Me.Panel_Footer.Name = "Panel_Footer"
        Me.Panel_Footer.Size = New System.Drawing.Size(266, 1)
        Me.Panel_Footer.TabIndex = 8
        '
        'RichTextBox_Footer
        '
        Me.RichTextBox_Footer.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RichTextBox_Footer.BackColor = System.Drawing.Color.White
        Me.RichTextBox_Footer.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox_Footer.Font = New System.Drawing.Font("Segoe UI Symbol", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox_Footer.ForeColor = System.Drawing.Color.Black
        Me.RichTextBox_Footer.Location = New System.Drawing.Point(3, 12)
        Me.RichTextBox_Footer.Name = "RichTextBox_Footer"
        Me.RichTextBox_Footer.ReadOnly = True
        Me.RichTextBox_Footer.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical
        Me.RichTextBox_Footer.Size = New System.Drawing.Size(260, 0)
        Me.RichTextBox_Footer.TabIndex = 0
        Me.RichTextBox_Footer.Text = resources.GetString("RichTextBox_Footer.Text")
        '
        'Panel_FormFooter
        '
        Me.Panel_FormFooter.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel_FormFooter.BackColor = System.Drawing.Color.Gainsboro
        Me.Panel_FormFooter.Controls.Add(Me.Label_TimerCountdown)
        Me.Panel_FormFooter.Controls.Add(Me.Button_Help)
        Me.Panel_FormFooter.Controls.Add(Me.FlowLayoutPanel_ResponseButtons)
        Me.Panel_FormFooter.Location = New System.Drawing.Point(0, 105)
        Me.Panel_FormFooter.Name = "Panel_FormFooter"
        Me.Panel_FormFooter.Size = New System.Drawing.Size(364, 46)
        Me.Panel_FormFooter.TabIndex = 16
        '
        'Label_TimerCountdown
        '
        Me.Label_TimerCountdown.AutoSize = True
        Me.Label_TimerCountdown.Font = New System.Drawing.Font("Segoe UI Variable Display", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_TimerCountdown.Location = New System.Drawing.Point(11, 15)
        Me.Label_TimerCountdown.Name = "Label_TimerCountdown"
        Me.Label_TimerCountdown.Size = New System.Drawing.Size(53, 15)
        Me.Label_TimerCountdown.TabIndex = 3
        Me.Label_TimerCountdown.Text = "00:00.000"
        Me.Label_TimerCountdown.Visible = False
        '
        'Msg
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(364, 151)
        Me.Controls.Add(Me.Panel_FormFooter)
        Me.Controls.Add(Me.TableLayoutPanel_MsgBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(800, 600)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(380, 190)
        Me.Name = "Msg"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Title"
        CType(Me.PictureBox_Icon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FlowLayoutPanel_ResponseButtons.ResumeLayout(False)
        Me.TableLayoutPanel_MsgBox.ResumeLayout(False)
        Me.Panel_Heading.ResumeLayout(False)
        Me.Panel_Message.ResumeLayout(False)
        CType(Me.PictureBox_Picture, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel_Footer.ResumeLayout(False)
        Me.Panel_FormFooter.ResumeLayout(False)
        Me.Panel_FormFooter.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PictureBox_Icon As PictureBox
    Friend WithEvents Button_Help As Button
    Friend WithEvents FlowLayoutPanel_ResponseButtons As FlowLayoutPanel
    Friend WithEvents Button_OK As Button
    Friend WithEvents Button_Cancel As Button
    Friend WithEvents Button_No As Button
    Friend WithEvents Button_Yes As Button
    Friend WithEvents Button_Continue As Button
    Friend WithEvents TableLayoutPanel_MsgBox As TableLayoutPanel
    Friend WithEvents Panel_Heading As Panel
    Friend WithEvents RichTextBox_Heading As RichTextBox
    Friend WithEvents Panel_Message As Panel
    Friend WithEvents RichTextBox_Message As RichTextBox
    Friend WithEvents PictureBox_Picture As PictureBox
    Friend WithEvents Panel_Footer As Panel
    Friend WithEvents RichTextBox_Footer As RichTextBox
    Friend WithEvents Panel_FormFooter As Panel
    Friend WithEvents Label_TimerCountdown As Label
End Class
