﻿


Imports System.Reflection
Imports Msg.Msg

Public Class Form1



    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboBox_ButtonOptions.Items.Clear()
        For Each optionName As Msg.ButtonOptions In [Enum].GetValues(GetType(Msg.ButtonOptions))
            ComboBox_ButtonOptions.Items.Add(Msg.FormatButtonOption(optionName.ToString()))
        Next

        ComboBox_LayoutOptions.Items.Clear()
        For Each layout As Msg.LayoutConfig In Msg.Layouts
            ComboBox_LayoutOptions.Items.Add(layout.description)
        Next

        ComboBox_IconOptions.Items.Clear()

        ' Loop through the dictionary keys (MsgIcon enum values)
        For Each iconKey As MsgIcon In MsgIconImages.Keys
            ComboBox_IconOptions.Items.Add(iconKey.ToString())
        Next

        ' Optionally select the first item by default
        If ComboBox_IconOptions.Items.Count > 0 Then
            If ComboBox_IconOptions.Items.Count >= 12 Then
                ComboBox_IconOptions.SelectedIndex = 12
            Else
                ComboBox_IconOptions.SelectedIndex = 0
            End If
        End If

        ComboBox_HelpFunction.DataSource = New List(Of String)(HelpFunctions.Keys)

        ComboBox_ButtonOptions.SelectedIndex = 0
        ComboBox_LayoutOptions.SelectedIndex = 12
        ComboBox_HelpFunction.SelectedIndex = 0
        ComboBox_Theme_ButtonStyles.SelectedIndex = 2
        ComboBox_Theme_Presets.SelectedIndex = 0
        ComboBox_DefaultButton.SelectedIndex = 0

        Dim picture As Image = Nothing
        Try
            Dim asm = Assembly.GetExecutingAssembly()
            Using stream = asm.GetManifestResourceStream("Msg.testImage.png")
                If stream IsNot Nothing Then
                    picture = Image.FromStream(stream)
                Else
                    'Debug.WriteLine("testImage resource not found.")
                End If
            End Using
        Catch ex As Exception
            'Debug.WriteLine("Error loading testImage: " & ex.Message)
        End Try


        Try
            PictureBox_PreviewPicture.Image = picture       '  Image.FromFile("pictures/MsgIcons/testImage.png")
        Catch ex As Exception
            Debug.WriteLine("Image File Not Found - testImage.png")
        End Try

    End Sub




    Private Sub Form1_Shown(sender As Object, e As EventArgs) Handles Me.Shown

    End Sub










    Private Sub ComboBox_IconOptions_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox_IconOptions.SelectedIndexChanged
        Dim selectedText As String = ComboBox_IconOptions.SelectedItem.ToString()
        Dim selectedIcon As MsgIcon
        If [Enum].TryParse(selectedText, selectedIcon) Then
            If MsgIconImages.ContainsKey(selectedIcon) Then
                PictureBox_PreviewIcon.Image = MsgIconImages(selectedIcon)
            Else
                PictureBox_PreviewIcon.Image = Nothing
            End If
        Else
            PictureBox_PreviewIcon.Image = Nothing
        End If
    End Sub




    Private Sub Button_Icon_Reset_Click(sender As Object, e As EventArgs) Handles Button_Icon_Reset.Click
        ComboBox_IconOptions.SelectedIndex = 0
        Dim selectedText As String = ComboBox_IconOptions.SelectedItem.ToString()
        Dim selectedIcon As MsgIcon
        If [Enum].TryParse(selectedText, selectedIcon) Then
            If MsgIconImages.ContainsKey(selectedIcon) Then
                PictureBox_PreviewIcon.Image = MsgIconImages(selectedIcon)
            Else
                PictureBox_PreviewIcon.Image = Nothing
            End If
        Else
            PictureBox_PreviewIcon.Image = Nothing
        End If
    End Sub


    Private Sub Button_Icon_Browse_Click(sender As Object, e As EventArgs) Handles Button_Icon_Browse.Click
        LoadImageIntoPictureBox(PictureBox_PreviewIcon)
    End Sub






    Private Sub Button_CompareToMessageBox_Click(sender As Object, e As EventArgs) Handles Button_CompareToMessageBox.Click

        Dim message As String = RichTextBox_Form1_Message.Text
        Dim title As String = TextBox_Form1_Title.Text

        Dim tempIcon As Image = Nothing
        Dim messageBoxIcon As MessageBoxIcon = MessageBoxIcon.None


        If CheckBox_ShowIcon.Checked Then
            If ComboBox_IconOptions.SelectedItem IsNot Nothing Then
                Dim selectedText As String = ComboBox_IconOptions.SelectedItem.ToString()
                Dim selectedIcon As MsgIcon

                If [Enum].TryParse(selectedText, selectedIcon) Then
                    If MsgIconImages.ContainsKey(selectedIcon) Then
                        tempIcon = MsgIconImages(selectedIcon)
                    End If

                    ' Map the selected icon to MessageBoxIcon
                    messageBoxIcon = MapToMessageBoxIcon(selectedIcon)
                End If
            End If
        End If

        Dim selectedButtonText As String = ComboBox_ButtonOptions.SelectedItem.ToString()
        Dim buttons As MessageBoxButtons = MapComboBoxToMessageBoxButtons(selectedButtonText)

        Dim result = MessageBox.Show(message, title, buttons, messageBoxIcon)

        Select Case result
            Case vbOK
                MessageBox.Show("You clicked OK!", title, MessageBoxButtons.OK, messageBoxIcon)

            Case vbYes
                MessageBox.Show("You clicked Yes!", title, MessageBoxButtons.OK, messageBoxIcon)

            Case vbNo
                MessageBox.Show("You clicked No!", title, MessageBoxButtons.OK, messageBoxIcon)

            Case vbCancel
                MessageBox.Show("You clicked Cancel!", title, MessageBoxButtons.OK, messageBoxIcon)
        End Select


        TextBox_ActualCode.Text = "MessageBox.Show(message, title, messageboxButton, messageBoxIcon)"

    End Sub



    Public Function MapComboBoxToMessageBoxButtons(selectedText As String) As MessageBoxButtons
        Select Case selectedText.Trim()
            Case "OK"
                Return MessageBoxButtons.OK

            Case "OK, Cancel", "Cancel, Continue"
                Return MessageBoxButtons.OKCancel

            Case "OK, No", "Yes, No", "No, Continue"
                Return MessageBoxButtons.YesNo

            Case "OK, No, Cancel", "Yes, No, Cancel"
                Return MessageBoxButtons.YesNoCancel

            Case Else
                Throw New ArgumentException("Unsupported button combination: " & selectedText)
        End Select
    End Function





    Private Function MapToMessageBoxIcon(icon As MsgIcon) As MessageBoxIcon
        Select Case icon
            Case MsgIcon.WindowsError, MsgIcon.WindowsErrorMargin, MsgIcon.ErrorRed, MsgIcon.ErrorRedMargin
                Return MessageBoxIcon.Error

            Case MsgIcon.WindowsWarning, MsgIcon.WarningMargin, MsgIcon.WindowsWarningMargin, MsgIcon.Warning
                Return MessageBoxIcon.Warning

            Case MsgIcon.WindowsInformation, MsgIcon.WindowsConfirmation,
             MsgIcon.WindowsInformationMargin, MsgIcon.WindowsConfirmationMargin,
             MsgIcon.Information, MsgIcon.ConfirmationMargin, MsgIcon.Confirmation,
             MsgIcon.InformationMargin
                Return MessageBoxIcon.Information

            Case MsgIcon.WindowsQuestion, MsgIcon.WindowsQuestionMargin, MsgIcon.Question, MsgIcon.QuestionMargin
                Return MessageBoxIcon.Question

            Case Else
                Return MessageBoxIcon.None
        End Select
    End Function





    Private Sub Button_ShowMsg_Click(sender As Object, e As EventArgs) Handles Button_ShowMsg.Click


        Dim title As String = TextBox_Form1_Title.Text

        Dim message As String
        If IsRichText(RichTextBox_Form1_Message) Then
            message = RichTextBox_Form1_Message.Rtf
        Else
            message = RichTextBox_Form1_Message.Text
        End If

        Dim heading As String
        If IsRichText(RichTextBox_Form1_Heading) Then
            heading = RichTextBox_Form1_Heading.Rtf
        Else
            heading = RichTextBox_Form1_Heading.Text
        End If

        Dim footer As String
        If IsRichText(RichTextBox_Form1_Footer) Then
            footer = RichTextBox_Form1_Footer.Rtf
        Else
            footer = RichTextBox_Form1_Footer.Text
        End If


        Dim X As Integer? = Nothing
        Dim y As Integer? = Nothing
        Dim Width As Integer? = Nothing
        Dim height As Integer? = Nothing

        Dim duration As Integer? = Nothing
        If CheckBox_TimedMessage.Checked Then
            duration = CInt(TextBox_Duration.Text)
        Else
            duration = Nothing
        End If

        ' Get selected Buttons from ComboBox2
        Dim selectedButtonOption As String = ComboBox_ButtonOptions.SelectedItem?.ToString()

        ' Default to first button option if none selected
        If String.IsNullOrEmpty(selectedButtonOption) Then
            selectedButtonOption = ComboBox_ButtonOptions.Items(0).ToString()
        End If

        ' Convert button text to ButtonOptions enum
        Dim buttonOption As Msg.ButtonOptions = Msg.GetButtonOptionFromText(selectedButtonOption)



        Dim selectedLayout As String = Nothing
        If CheckBox_OverrideLayout.Checked Then
            ' Get selected Layout from ComboBox1
            selectedLayout = ComboBox_LayoutOptions.SelectedItem?.ToString()

            ' Default to first layout if none selected
            If String.IsNullOrEmpty(selectedLayout) Then
                selectedLayout = ComboBox_LayoutOptions.Items(0).ToString()
            End If
        End If


        If CheckBox_OverrideSizePosition.Checked Then
            X = CInt(TextBox_X.Text)
            y = CInt(TextBox_Y.Text)
            Width = CInt(TextBox_Width.Text)
            height = CInt(TextBox_Height.Text)
        Else
            X = Nothing
            y = Nothing
            Width = Nothing
            height = Nothing
        End If

        Dim picture As Image = Nothing
        Try
            Dim asm = Assembly.GetExecutingAssembly()
            Using stream = asm.GetManifestResourceStream("Msg.testImage.png")
                If stream IsNot Nothing Then
                    picture = Image.FromStream(stream)
                Else
                    'Debug.WriteLine("testImage resource not found.")
                End If
            End Using
        Catch ex As Exception
            'Debug.WriteLine("Error loading testImage: " & ex.Message)
        End Try

        If CheckBox_ShowPicture.Checked Then
            picture = PictureBox_PreviewPicture.Image   ' Image.FromFile("pictures/testImage.png")
        Else
            picture = Nothing
        End If



        Dim tempIcon As Image
        If CheckBox_ShowIcon.Checked Then
            ' Ensure something is selected
            If ComboBox_IconOptions.SelectedItem IsNot Nothing Then
                Dim selectedText As String = ComboBox_IconOptions.SelectedItem.ToString()

                ' Try to convert the string back to the MsgIcon enum
                Dim selectedIcon As MsgIcon
                If [Enum].TryParse(selectedText, selectedIcon) Then
                    ' Check if the icon exists in the dictionary
                    If MsgIconImages.ContainsKey(selectedIcon) Then
                        tempIcon = MsgIconImages(selectedIcon)
                    End If
                End If
            End If
        Else
            tempIcon = Nothing
        End If



        ' Define your theme
        Dim customTheme As Msg.MessageBoxTheme
        If CheckBox_CustomTheme.Checked Then
            ' Attempt to parse the selected ComboBox text to FlatStyle enum
            Dim selectedStyle As FlatStyle = FlatStyle.Standard ' Default fallback
            If [Enum].TryParse(ComboBox_Theme_ButtonStyles.SelectedItem.ToString(), selectedStyle) Then
                ' Parsed successfully
            End If

            customTheme = New Msg.MessageBoxTheme With {
        .BackColor = PictureBox_Theme_BackColour.BackColor,
        .FontColor = PictureBox_Theme_FontColour.BackColor,
        .FooterColor = PictureBox_Theme_FooterColour.BackColor,
        .ButtonColor = PictureBox_Theme_ButtonColour.BackColor,
        .ButtonFontColor = PictureBox_Theme_ButtonFontColour.BackColor,
        .ButtonStyle = selectedStyle
    }
        Else
            customTheme = Nothing
        End If


        Dim selectedHelpKey As String = ComboBox_HelpFunction.SelectedItem.ToString()
        Dim selectedHelpFunction As Func(Of String) = Nothing

        Dim result As Msg.DialogResultCustom

        If CheckBox_ShowHelpButton.Checked Then
            If HelpFunctions.ContainsKey(selectedHelpKey) Then
                selectedHelpFunction = HelpFunctions(selectedHelpKey)
            Else
                MessageBox.Show("Please select a valid help option.")
                Exit Sub
            End If
        Else
            selectedHelpFunction = Nothing
        End If



        result = Msg.Box(message, title, heading, footer, buttonOption, tempIcon, picture, Nothing, customTheme, selectedHelpFunction, duration, X, y, Width, height, selectedLayout)
        'Dim result As Msg.DialogResultCustom = Msg.Box(message, title, heading, footer, X, y, Width, height, picture, tempIcon, layout, Msg.ButtonOptions.YesNoCancel)


        Select Case result
            Case Msg.DialogResultCustom.Yes
                Msg.Box("You clicked Yes!", title, "", "", MsgButtons.OK, tempIcon, Nothing, Nothing, customTheme, Nothing, Nothing, X, y, Width, height, selectedLayout)

            Case Msg.DialogResultCustom.No
                Msg.Box("You clicked No.", title, "", "", MsgButtons.OK, tempIcon, Nothing, Nothing, customTheme, Nothing, Nothing, X, y, Width, height, selectedLayout)

            Case Msg.DialogResultCustom.Cancel
                Msg.Box("You clicked Cancel.", title, "", "", MsgButtons.OK, tempIcon, Nothing, Nothing, customTheme, Nothing, Nothing, X, y, Width, height, selectedLayout)

            Case Msg.DialogResultCustom.OK
                Msg.Box("You clicked OK.", title, "", "", MsgButtons.OK, tempIcon, Nothing, Nothing, customTheme, Nothing, Nothing, X, y, Width, height, selectedLayout)

            Case Msg.DialogResultCustom.ContinueOn
                Msg.Box("You clicked Continue.", title, "", "", MsgButtons.OK, tempIcon, Nothing, Nothing, customTheme, Nothing, Nothing, X, y, Width, height, selectedLayout)

            Case Msg.DialogResultCustom.None
                Msg.Box("You clicked nothing - dialog was closed", title, "", "", MsgButtons.OK, tempIcon, Nothing, Nothing, customTheme, Nothing, Nothing, X, y, Width, height, selectedLayout)
        End Select


        TextBox_ActualCode.Text = "Msg.Box(message, title, heading, footer, MsgButton, MsgIcon, picture, defaultButton, customTheme, selectedHelpFunction, duration, X, y, Width, height, selectedLayout)"

    End Sub







    Private Sub Button_ShowMsgNew_Click(sender As Object, e As EventArgs) Handles Button_ShowMsgNew.Click

        Dim newFormInstance As New Msg
        Dim title As String = TextBox_Form1_Title.Text

        Dim message As String
        If IsRichText(RichTextBox_Form1_Message) Then
            message = RichTextBox_Form1_Message.Rtf
        Else
            message = RichTextBox_Form1_Message.Text
        End If

        Dim heading As String
        If IsRichText(RichTextBox_Form1_Heading) Then
            heading = RichTextBox_Form1_Heading.Rtf
        Else
            heading = RichTextBox_Form1_Heading.Text
        End If

        Dim footer As String
        If IsRichText(RichTextBox_Form1_Footer) Then
            footer = RichTextBox_Form1_Footer.Rtf
        Else
            footer = RichTextBox_Form1_Footer.Text
        End If



        Dim X As Integer? = Nothing
        Dim y As Integer? = Nothing
        Dim Width As Integer? = Nothing
        Dim height As Integer? = Nothing

        Dim duration As Integer = Nothing


        ' Get selected Buttons from ComboBox2
        Dim selectedButtonOption As String = ComboBox_ButtonOptions.SelectedItem?.ToString()

        ' Default to first button option if none selected
        If String.IsNullOrEmpty(selectedButtonOption) Then
            selectedButtonOption = ComboBox_ButtonOptions.Items(0).ToString()
        End If

        ' Convert button text to ButtonOptions enum
        Dim buttonOption As Msg.ButtonOptions = Msg.GetButtonOptionFromText(selectedButtonOption)



        Dim selectedLayout As String = Nothing
        If CheckBox_OverrideLayout.Checked Then
            ' Get selected Layout from ComboBox1
            selectedLayout = ComboBox_LayoutOptions.SelectedItem?.ToString()

            ' Default to first layout if none selected
            If String.IsNullOrEmpty(selectedLayout) Then
                selectedLayout = ComboBox_LayoutOptions.Items(0).ToString()
            End If
        End If


        If CheckBox_OverrideSizePosition.Checked Then
            X = CInt(TextBox_X.Text)
            y = CInt(TextBox_Y.Text)
            Width = CInt(TextBox_Width.Text)
            height = CInt(TextBox_Height.Text)
        Else
            X = Nothing
            y = Nothing
            Width = Nothing
            height = Nothing
        End If


        Dim picture As Image = Nothing
        Try
            Dim asm = Assembly.GetExecutingAssembly()
            Using stream = asm.GetManifestResourceStream("Msg.testImage.png")
                If stream IsNot Nothing Then
                    picture = Image.FromStream(stream)
                Else
                    'Debug.WriteLine("testImage resource not found.")
                End If
            End Using
        Catch ex As Exception
            'Debug.WriteLine("Error loading testImage: " & ex.Message)
        End Try


        If CheckBox_ShowPicture.Checked Then
            picture = PictureBox_PreviewPicture.Image   ' Image.FromFile("pictures/testImage.png")
        Else
            picture = Nothing
        End If



        Dim tempIcon As Image = Nothing
        If CheckBox_ShowIcon.Checked Then
            ' Ensure something is selected
            If ComboBox_IconOptions.SelectedItem IsNot Nothing Then
                Dim selectedText As String = ComboBox_IconOptions.SelectedItem.ToString()

                ' Try to convert the string back to the MsgIcon enum
                Dim selectedIcon As MsgIcon
                If [Enum].TryParse(selectedText, selectedIcon) Then
                    ' Check if the icon exists in the dictionary
                    If MsgIconImages.ContainsKey(selectedIcon) Then
                        tempIcon = MsgIconImages(selectedIcon)
                    End If
                End If
            End If
        Else
            tempIcon = Nothing
        End If



        ' Define your theme
        Dim customTheme As Msg.MessageBoxTheme
        If CheckBox_CustomTheme.Checked Then
            ' Attempt to parse the selected ComboBox text to FlatStyle enum
            Dim selectedStyle As FlatStyle = FlatStyle.Standard ' Default fallback
            If [Enum].TryParse(ComboBox_Theme_ButtonStyles.SelectedItem.ToString(), selectedStyle) Then
                ' Parsed successfully
            End If

            customTheme = New Msg.MessageBoxTheme With {
        .BackColor = PictureBox_Theme_BackColour.BackColor,
        .FontColor = PictureBox_Theme_FontColour.BackColor,
        .FooterColor = PictureBox_Theme_FooterColour.BackColor,
        .ButtonColor = PictureBox_Theme_ButtonColour.BackColor,
        .ButtonFontColor = PictureBox_Theme_ButtonFontColour.BackColor,
        .ButtonStyle = selectedStyle
    }
        Else
            customTheme = Nothing
        End If


        Dim selectedHelpKey As String = ComboBox_HelpFunction.SelectedItem.ToString()
        Dim selectedHelpFunction As Func(Of String) = Nothing

        Dim result As Msg.DialogResultCustom

        If CheckBox_ShowHelpButton.Checked Then
            If HelpFunctions.ContainsKey(selectedHelpKey) Then
                selectedHelpFunction = HelpFunctions(selectedHelpKey)
            Else
                MessageBox.Show("Please select a valid help option.")
                Exit Sub
            End If
        Else
            selectedHelpFunction = Nothing
        End If



        result = newFormInstance.Box(message, title, heading, footer, buttonOption, tempIcon, picture, Nothing, customTheme, selectedHelpFunction, duration, X, y, Width, height, selectedLayout)
        'Dim result As Msg.DialogResultCustom = Msg.Box(message, title, heading, footer, X, y, Width, height, picture, tempIcon, layout, Msg.ButtonOptions.YesNoCancel)


        Select Case result
            Case Msg.DialogResultCustom.Yes
                Msg.Box("You clicked Yes!", title, "", "", MsgButtons.OK, tempIcon, Nothing, Nothing, customTheme, Nothing, Nothing, X, y, Width, height, selectedLayout)

            Case Msg.DialogResultCustom.No
                Msg.Box("You clicked No.", title, "", "", MsgButtons.OK, tempIcon, Nothing, Nothing, customTheme, Nothing, Nothing, X, y, Width, height, selectedLayout)

            Case Msg.DialogResultCustom.Cancel
                Msg.Box("You clicked Cancel.", title, "", "", MsgButtons.OK, tempIcon, Nothing, Nothing, customTheme, Nothing, Nothing, X, y, Width, height, selectedLayout)

            Case Msg.DialogResultCustom.OK
                Msg.Box("You clicked OK.", title, "", "", MsgButtons.OK, tempIcon, Nothing, Nothing, customTheme, Nothing, Nothing, X, y, Width, height, selectedLayout)

            Case Msg.DialogResultCustom.ContinueOn
                Msg.Box("You clicked Continue.", title, "", "", MsgButtons.OK, tempIcon, Nothing, Nothing, customTheme, Nothing, Nothing, X, y, Width, height, selectedLayout)

            Case Msg.DialogResultCustom.None
                Msg.Box("You clicked nothing - dialog was closed", title, "", "", MsgButtons.OK, tempIcon, Nothing, Nothing, customTheme, Nothing, Nothing, X, y, Width, height, selectedLayout)
        End Select


        TextBox_ActualCode.Text = "newFormInstance.Box(message, title, heading, footer, MsgButton, MsgIcon, picture, defaultButton, customTheme, selectedHelpFunction, duration, X, y, Width, height, selectedLayout)"

    End Sub





    Private Sub Button_SimpleMsg_Click(sender As Object, e As EventArgs) Handles Button_SimpleMsg.Click

        Dim title As String = TextBox_Form1_Title.Text

        Dim message As String = RichTextBox_Form1_Message.Text
        Dim heading As String = RichTextBox_Form1_Heading.Text
        Dim footer As String = RichTextBox_Form1_Footer.Text

        Dim tempIcon As Image = Nothing
        If CheckBox_ShowIcon.Checked Then
            If ComboBox_IconOptions.SelectedItem IsNot Nothing Then
                Dim selectedText As String = ComboBox_IconOptions.SelectedItem.ToString()
                Dim selectedIcon As MsgIcon
                If [Enum].TryParse(selectedText, selectedIcon) Then
                    If MsgIconImages.ContainsKey(selectedIcon) Then
                        tempIcon = MsgIconImages(selectedIcon)
                    End If
                End If
            End If
        Else
            tempIcon = Nothing
        End If

        Msg.Box(message, title, heading, footer, Msg.ButtonOptions.OK, tempIcon)

        TextBox_ActualCode.Text = "Msg.Box(message, title, heading, footer, MsgButton, MsgIcon)"

    End Sub




    Private Sub Button_SimpleMsgNew_Click(sender As Object, e As EventArgs) Handles Button_SimpleMsgNew.Click

        Dim newFormInstance As New Msg

        Dim title As String = TextBox_Form1_Title.Text

        Dim message As String = RichTextBox_Form1_Message.Text
        Dim heading As String = RichTextBox_Form1_Heading.Text
        Dim footer As String = RichTextBox_Form1_Footer.Text

        Dim tempIcon As Image = Nothing
        If CheckBox_ShowIcon.Checked Then
            If ComboBox_IconOptions.SelectedItem IsNot Nothing Then
                Dim selectedText As String = ComboBox_IconOptions.SelectedItem.ToString()
                Dim selectedIcon As MsgIcon
                If [Enum].TryParse(selectedText, selectedIcon) Then
                    If MsgIconImages.ContainsKey(selectedIcon) Then
                        tempIcon = MsgIconImages(selectedIcon)
                    End If
                End If
            End If
        Else
            tempIcon = Nothing
        End If

        newFormInstance.Box(message, title, heading, footer, Msg.ButtonOptions.OK, tempIcon)

        TextBox_ActualCode.Text = " newFormInstance.Box(message, title, heading, footer, MsgButton, MsgIcon)"

    End Sub




    Private Delegate Function HelpFunctionDelegate() As String

    Private Sub CheckBox_ShowHelpButton_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_ShowHelpButton.CheckedChanged
        Panel_HelpFunction.Enabled = CheckBox_ShowHelpButton.Checked
    End Sub


    Private HelpFunctions As New Dictionary(Of String, Func(Of String)) From {
        {"Help Option 1", AddressOf MyHelpFunction1},
        {"Help Option 2", AddressOf MyHelpFunction2},
        {"Help Option 3", AddressOf MyHelpFunction3},
        {"Help Option 4", AddressOf MyHelpFunction4}
    }

    Private Function MyHelpFunction1() As String
        Return "1 Here's how to use this message box..."
                End Function

    Private Function MyHelpFunction2() As String

        Return "2 Here's how to use this message box..."
    End Function

    Private Function MyHelpFunction3() As String
        Return "3 Here's how to use this message box..."
    End Function

    Private Function MyHelpFunction4() As String
        Return "4 Here's how to use this message box..."
    End Function





    Private Sub CheckBox_TimedMessage_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_TimedMessage.CheckedChanged
        Panel_TimedDuration.Enabled = CheckBox_TimedMessage.Checked
    End Sub

    Private Sub TextBox_Duration_TextChanged(sender As Object, e As EventArgs) Handles TextBox_Duration.TextChanged

    End Sub

    Private Sub TextBox_Duration_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox_Duration.KeyPress
        ' Allow only digits and control keys (e.g. backspace)
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True ' Block the input
        End If
    End Sub






    Private Sub CheckBox_OverrideLayout_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_OverrideLayout.CheckedChanged
        Panel_OverrideLayout.Enabled = CheckBox_OverrideLayout.Checked
    End Sub

    Private Sub Button_OverrideLayoutReset_Click(sender As Object, e As EventArgs) Handles Button_OverrideLayoutReset.Click

    End Sub

    Private Sub CheckBox_OverrideSizePosition_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_OverrideSizePosition.CheckedChanged
        Panel_OverrideSizePosition.Enabled = CheckBox_OverrideSizePosition.Checked
    End Sub


    Private Sub TextBox_X_TextChanged(sender As Object, e As EventArgs) Handles TextBox_X.TextChanged

    End Sub
    Private Sub TextBox_X_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox_X.KeyPress
        ' Allow only digits and control keys (e.g. backspace)
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True ' Block the input
        End If
    End Sub



    Private Sub TextBox_Y_TextChanged(sender As Object, e As EventArgs) Handles TextBox_Y.TextChanged

    End Sub
    Private Sub TextBox_Y_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox_Y.KeyPress
        ' Allow only digits and control keys (e.g. backspace)
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True ' Block the input
        End If
    End Sub



    Private Sub TextBox_Width_TextChanged(sender As Object, e As EventArgs) Handles TextBox_Width.TextChanged

    End Sub
    Private Sub TextBox_Width_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox_Width.KeyPress
        ' Allow only digits and control keys (e.g. backspace)
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True ' Block the input
        End If
    End Sub



    Private Sub TextBox_Height_TextChanged(sender As Object, e As EventArgs) Handles TextBox_Height.TextChanged

    End Sub
    Private Sub TextBox_Height_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox_Height.KeyPress
        ' Allow only digits and control keys (e.g. backspace)
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) Then
            e.Handled = True ' Block the input
        End If
    End Sub







    Private Sub CheckBox_ShowPicture_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_ShowPicture.CheckedChanged
        PictureBox_PreviewPicture.Enabled = CheckBox_ShowPicture.Checked
    End Sub


    Private Sub LoadImageIntoPictureBox(ByRef passedPicturebox As PictureBox)
        Using openFileDialog As New OpenFileDialog()
            openFileDialog.Title = "Select an Image"
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif"
            openFileDialog.Multiselect = False

            If openFileDialog.ShowDialog() = DialogResult.OK Then
                Try
                    Dim selectedImage As Image = Image.FromFile(openFileDialog.FileName)
                    passedPicturebox.Image = selectedImage
                Catch ex As Exception
                    MessageBox.Show("Failed to load image: " & ex.Message)
                End Try
            End If
        End Using
    End Sub


    Private Sub Button_BrowseForPicture_Click(sender As Object, e As EventArgs) Handles Button_BrowseForPicture.Click
        LoadImageIntoPictureBox(PictureBox_PreviewPicture)
    End Sub


    Private Sub Button_ResetPicture_Click(sender As Object, e As EventArgs) Handles Button_ResetPicture.Click

        Dim picture As Image = Nothing
        Try
            Dim asm = Assembly.GetExecutingAssembly()
            Using stream = asm.GetManifestResourceStream("Msg.testImage.png")
                If stream IsNot Nothing Then
                    picture = Image.FromStream(stream)
                Else
                    'Debug.WriteLine("testImage resource not found.")
                End If
            End Using
        Catch ex As Exception
            'Debug.WriteLine("Error loading testImage: " & ex.Message)
        End Try


        PictureBox_PreviewPicture.Image = picture ' Image.FromFile("pictures/testImage.png")
    End Sub


    Private Sub CheckBox_CustomTheme_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_CustomTheme.CheckedChanged
        Panel_Theme.Enabled = CheckBox_CustomTheme.Checked
    End Sub



    Private Sub Button_Theme_Reset_Click(sender As Object, e As EventArgs) Handles Button_Theme_Reset.Click
        PictureBox_Theme_BackColour.BackColor = defaultThemeMsg_BackColour
        PictureBox_Theme_FontColour.BackColor = defaultThemeMsg_FontColour
        PictureBox_Theme_ButtonColour.BackColor = defaultThemeMsg_ButtonColour
        PictureBox_Theme_ButtonFontColour.BackColor = defaultThemeMsg_ButtonFontColour
        PictureBox_Theme_FooterColour.BackColor = defaultThemeMsg_FooterColour
        ComboBox_Theme_ButtonStyles.SelectedIndex = 2
        ComboBox_Theme_Presets.SelectedIndex = 0
    End Sub



    Private Sub ComboBox_Theme_Presets_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox_Theme_Presets.SelectedIndexChanged
        Dim selecteOption As String = ComboBox_Theme_Presets.SelectedItem.ToString()
        Select Case selecteOption
            Case "Default"
                PictureBox_Theme_BackColour.BackColor = defaultThemeMsg_BackColour
                PictureBox_Theme_FontColour.BackColor = defaultThemeMsg_FontColour
                PictureBox_Theme_ButtonColour.BackColor = defaultThemeMsg_ButtonColour
                PictureBox_Theme_ButtonFontColour.BackColor = defaultThemeMsg_ButtonFontColour
                PictureBox_Theme_FooterColour.BackColor = defaultThemeMsg_FooterColour
                ComboBox_Theme_ButtonStyles.SelectedIndex = 2

            Case "Light"
                PictureBox_Theme_BackColour.BackColor = Color.FromArgb(255, 248, 250, 252)
                PictureBox_Theme_FontColour.BackColor = Color.FromArgb(255, 80, 87, 94)
                PictureBox_Theme_ButtonColour.BackColor = Color.FromArgb(255, 248, 250, 252)
                PictureBox_Theme_ButtonFontColour.BackColor = Color.FromArgb(255, 80, 87, 94)
                PictureBox_Theme_FooterColour.BackColor = Color.FromArgb(255, 188, 204, 220)
                ComboBox_Theme_ButtonStyles.SelectedIndex = 2

            Case "Dark"
                PictureBox_Theme_BackColour.BackColor = Color.FromArgb(255, 30, 30, 30)
                PictureBox_Theme_FontColour.BackColor = Color.FromArgb(255, 200, 200, 200)
                PictureBox_Theme_ButtonColour.BackColor = Color.FromArgb(255, 46, 46, 46)
                PictureBox_Theme_ButtonFontColour.BackColor = Color.FromArgb(255, 200, 200, 200)
                PictureBox_Theme_FooterColour.BackColor = Color.FromArgb(255, 90, 90, 90)
                ComboBox_Theme_ButtonStyles.SelectedIndex = 0

        End Select
    End Sub



    Private Sub PictureBox_Theme_BackColour_Click(sender As Object, e As EventArgs) Handles PictureBox_Theme_BackColour.Click
        Using colorDialog As New ColorDialog()
            If colorDialog.ShowDialog() = DialogResult.OK Then
                PictureBox_Theme_BackColour.BackColor = colorDialog.Color
            End If
        End Using
    End Sub

    Private Sub PictureBox_Theme_FontColour_Click(sender As Object, e As EventArgs) Handles PictureBox_Theme_FontColour.Click
        Using colorDialog As New ColorDialog()
            If colorDialog.ShowDialog() = DialogResult.OK Then
                PictureBox_Theme_FontColour.BackColor = colorDialog.Color
            End If
        End Using
    End Sub

    Private Sub PictureBox_Theme_ButtonColour_Click(sender As Object, e As EventArgs) Handles PictureBox_Theme_ButtonColour.Click
        Using colorDialog As New ColorDialog()
            If colorDialog.ShowDialog() = DialogResult.OK Then
                PictureBox_Theme_ButtonColour.BackColor = colorDialog.Color
            End If
        End Using
    End Sub

    Private Sub PictureBox_Theme_FooterColour_Click(sender As Object, e As EventArgs) Handles PictureBox_Theme_FooterColour.Click
        Using colorDialog As New ColorDialog()
            If colorDialog.ShowDialog() = DialogResult.OK Then
                PictureBox_Theme_FooterColour.BackColor = colorDialog.Color
            End If
        End Using
    End Sub

    Private Sub PictureBox_Theme_ButtonFontColour_Click(sender As Object, e As EventArgs) Handles PictureBox_Theme_ButtonFontColour.Click
        Using colorDialog As New ColorDialog()
            If colorDialog.ShowDialog() = DialogResult.OK Then
                PictureBox_Theme_ButtonFontColour.BackColor = colorDialog.Color
            End If
        End Using
    End Sub





    Private Sub Button_Code_Clear_Click(sender As Object, e As EventArgs) Handles Button_Code_Clear.Click
        TextBox_ActualCode.Text = ""
    End Sub

    Private Sub Button_Code_Copy_Click(sender As Object, e As EventArgs) Handles Button_Code_Copy.Click
        If Not String.IsNullOrEmpty(TextBox_ActualCode.Text) Then
            Clipboard.SetText(TextBox_ActualCode.Text)
            MessageBox.Show("Text copied to clipboard!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            MessageBox.Show("TextBox is empty.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub




    Private Sub Button_RTF_RefreshMessage_Click(sender As Object, e As EventArgs) Handles Button_RTF_RefreshMessage.Click
        TextBox_RTF_Message.Text = RichTextBox_Form1_Message.Rtf.ToString()
    End Sub

    Private Sub Button_RTF_RefreshHeading_Click(sender As Object, e As EventArgs) Handles Button_RTF_RefreshHeading.Click
        TextBox_RTF_Heading.Text = RichTextBox_Form1_Heading.Rtf.ToString()
    End Sub

    Private Sub Button_RTF_RefreshFooter_Click(sender As Object, e As EventArgs) Handles Button_RTF_RefreshFooter.Click
        TextBox_RTF_Footer.Text = RichTextBox_Form1_Footer.Rtf.ToString()
    End Sub



    Private Sub Button_RTF_ClearMessage_Click(sender As Object, e As EventArgs) Handles Button_RTF_ClearMessage.Click
        TextBox_RTF_Message.Clear()
    End Sub

    Private Sub Button_RTF_ClearHeading_Click(sender As Object, e As EventArgs) Handles Button_RTF_ClearHeading.Click
        TextBox_RTF_Heading.Clear()
    End Sub

    Private Sub Button_RTF_ClearFooter_Click(sender As Object, e As EventArgs) Handles Button_RTF_ClearFooter.Click
        TextBox_RTF_Footer.Clear()
    End Sub



    Private Sub Button_Form1_MessageClear_Click(sender As Object, e As EventArgs) Handles Button_Form1_MessageClear.Click
        RichTextBox_Form1_Message.Clear()
        RichTextBox_Form1_Message.Text = RichTextBox_Form1_Message.Text
    End Sub

    Private Sub Button_Form1_MessageAsPlain_Click(sender As Object, e As EventArgs) Handles Button_Form1_MessageAsPlain.Click
        ResetRichTextBox(RichTextBox_Form1_Message)
    End Sub




    Private Sub Button_Form1_HeadingClear_Click(sender As Object, e As EventArgs) Handles Button_Form1_HeadingClear.Click
        RichTextBox_Form1_Heading.Clear()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button_Form1_HeadingAsPlain.Click
        ResetRichTextBox(RichTextBox_Form1_Heading)
    End Sub




    Private Sub Button_Form1_FooterClear_Click(sender As Object, e As EventArgs) Handles Button_Form1_FooterClear.Click
        RichTextBox_Form1_Footer.Clear()
        RichTextBox_Form1_Footer.Text = RichTextBox_Form1_Footer.Text
    End Sub


    Private Sub Button_Form1_FooterAsPlain_Click(sender As Object, e As EventArgs) Handles Button_Form1_FooterAsPlain.Click
        ResetRichTextBox(RichTextBox_Form1_Footer)
    End Sub





    Private Sub Button_Quit_Click(sender As Object, e As EventArgs) Handles Button_Quit.Click
        Application.Exit()
    End Sub


End Class



